/***********************************************
*
* @Proposit: Conté les estructures de dades principals del programa
*             (Kingdom, Route, Product, TradeList) i funcions auxiliars
*             per mostrar informació relacionada amb aquestes estructures.
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#include "structs.h"

/***********************************************
*
* @Finalitat: Mostra per pantalla el nom del regne actual conegut i els regnes als qui té una ruta.
* @Parametres:
*   - kingdom: estructura que conté la informació del regne actual.
* @Retorn: void.
*
************************************************/

void list_realms(Kingdom kingdom) {
    printStatic("\nKnown Realms:\n");

    
    char *buf;
    int len = asprintf(&buf, "- %s\n", kingdom.name);
    write(STDOUT_FILENO, buf, len);
    free(buf);

    for (int i = 0; i < kingdom.n_routes; i++) {
        if (!kingdom.routes[i].dest)
            continue;

        if (strcmp(kingdom.routes[i].dest, "DEFAULT") == 0)
            continue;

        len = asprintf(&buf, "- %s\n", kingdom.routes[i].dest);
        write(STDOUT_FILENO, buf, len);
        free(buf);
    }

    printStatic("\n");
}


/***********************************************
*
* @Finalitat: Mostra una taula amb els productes locals del regne.
* @Parametres:
*   - products: llista de productes.
*   - n_products: nombre total de productes.
* @Retorn: void.
*
************************************************/

void list_local_products(Product *products, int n_products) {
    char *msg = NULL;

    printStatic("\n--- Trade Ledger ---\n");
    printStatic("Item | Value (Gold) | Weight (Stone)\n");
    printStatic("--------------------------------------------------------\n");

    for (int i = 0; i < n_products; i++) {
        msg = GLOBAL_dynamicFormat("%-25s | %-5d | %-5.1f\n",
                           products[i].name,
                           products[i].amount,
                           products[i].weight);
        if (msg) {
            printStatic(msg);
            GLOBAL_FREE(msg);
        }
    }

    printStatic("--------------------------------------------------------\n");
    msg = GLOBAL_dynamicFormat("Total Entries: %d\n", n_products);
    if (msg) {
        printStatic(msg);
        GLOBAL_FREE(msg);
    }
    

}

/***********************************************
*
* @Finalitat: Mostra una llista simple de productes disponibles per comerciar.
* @Parametres:
*   - products: llista de productes.
*   - n_products: nombre total de productes.
* @Retorn: void.
*
************************************************/

void list_available_products(Product *products, int n_products){
    printStatic("Available products: ");
    for(int i = 0; i < n_products; i++){
        write(1, products[i].name, strlen(products[i].name));
        if(i == n_products - 1)
            printStatic(".\n");
        else 
            printStatic(", ");
        
    }
}