#ifndef MAIN_CONTROLLER_H
#define MAIN_CONTROLLER_H

#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/select.h>
#include <stdlib.h>
#include <ctype.h>
#include "structs.h"
#include "auxiliars.h"
#include "trade_controller.h"
#include "protocol.h"
#include "network_controller.h"
#include "envoy_controller.h"

#define CMD_LIST            "list"                                                                          //Comanda per llistar elements.
#define CMD_PLEDGE          "pledge"                                                                        //Comanda per fer un jurament o compromís.
#define CMD_START           "start"                                                                         //Comanda per iniciar un procés (per ex. un trade).
#define CMD_ENVOY           "envoy"                                                                         //Comanda relacionada amb l’enviament o missatger.
#define SUB_STATUS          "status"                                                                        //Subcomanda per veure l'estat.
#define SUB_RESPOND         "respond"                                                                       //Subcomanda per respondre a altres realms.
#define SUB_REALMS          "realms"                                                                        //Subcomanda per llistar regnes.
#define SUB_PRODUCTS        "products"                                                                      //Subcomanda per llistar productes.
#define SUB_TRADE           "trade"                                                                         //Subcomanda per iniciar comerç.

#define MISS                "Missing arguments.Please review the syntax.\n"                                 //Missatge d'error per falta d'arguments.
#define MISS_LIST           "Missing arguments, can’t list. Please review the syntax.\n"                    //Missatge d'error per falta d'arguments.
#define MISS_START_TRADE    "Missing arguments, can’t start a trade. Please review the syntax.\n"           //Missatge d'error per falta d'arguments.
#define MISS_TRADE          "Missing arguments, can’t trade. Please review the syntax.\n"                   //Missatge d'error per falta d'arguments.

/***********************************************
*
* @Finalitat: Controla el menú principal del programa Maester.
*              Llegeix les comandes de l’usuari i crida el processament corresponent.
* @Parametres:
*   - products: llista de productes locals del regne.
*   - n_products: nombre total de productes disponibles.
*   - kingdom: estructura amb la informació del regne actual.
*   - main_line: punter a la línia activa del menú principal.
*   - trade_line: punter a la línia activa del mode trade.
*   - trade_list: punter a la llista d’intercanvi de productes.
*   - other_products: punter a la llista de productes d’un altre regne (per proves).
* @Retorn: void.
*
************************************************/

void menu_principal(GlobalContext *ctx, int pipeCTRLC[2]);

#endif
