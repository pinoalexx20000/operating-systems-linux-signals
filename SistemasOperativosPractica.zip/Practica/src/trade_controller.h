/***********************************************
*
* @Proposit: Gestiona la lògica principal de les transaccions comercials (trade) entre regnes,
*             incloent l’afegit de productes a la llista de compra i l’enviament final de la llista.
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#ifndef TRADE_CONTROLLER_H
#define TRADE_CONTROLLER_H

#define _GNU_SOURCE
#include <string.h>
#include <stdlib.h>
#include "structs.h"
#include "auxiliars.h"
#include "persistence.h"
#include "envoy_controller.h"
#include "safe_print.h"
#include <fcntl.h>


/***********************************************
*
* @Finalitat: Controla el mode de comerç amb un regne concret.
*              Mostra els productes disponibles i processa les comandes de l’usuari.
* @Parametres:
*   - products: array amb els productes disponibles del regne.
*   - n_products: nombre total de productes.
*   - kingdom: estructura amb la informació del regne amb el qual es negocia.
* @Retorn: void.
*
************************************************/

void menu_trade(GlobalContext *ctx, char *realm);

#endif
