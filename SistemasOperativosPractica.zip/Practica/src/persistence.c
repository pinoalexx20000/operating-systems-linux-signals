/***********************************************
*
* @Proposit: Gestiona la persistència de dades del programa, incloent la lectura del regne,
*             la càrrega de productes i el desament de la llista de comerç (trade list).
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#include "persistence.h"


/***********************************************
*
* @Finalitat: Llegeix les dades del regne des d’un fitxer i inicialitza l’estructura Kingdom.
* @Parametres:
*   - k: punter a l’estructura Kingdom on es desaran les dades.
*   - fd: file descriptor obert amb la informació del regne.
* @Retorn: void.
*
************************************************/

void getKingdom(Kingdom *k, int fd) {
    int n_routes = 0;
    Route *routes = NULL;

    // Llegir nom del regne
    k->name = read_until(fd, '\n');
    if (!k->name || strlen(k->name) == 0) {
        free(k->name);
        k->name = NULL;
        return;
    }

    if (k->name[strlen(k->name)-1] == '\r') k->name[strlen(k->name)-1] = '\0';

    // Netejar caràcter '&'
    char *src = k->name;
    char *dst = k->name;
    while (*src) {
        if (*src != '&') *dst++ = *src;
        src++;
    }
    *dst = '\0';

    // Llegir path
    char *tmp = read_until(fd, '\n');
    if (tmp[strlen(tmp)-1] == '\n') tmp[strlen(tmp)-1] = '\0';
    k->path = strdup(tmp);
    if (k->path[strlen(k->path)-1] == '\r') k->path[strlen(k->path)-1] = '\0';
    free(tmp);

    // Llegir nombre d’enviats
    tmp = read_until(fd, '\n');
    k->envoys = atoi(tmp);
    free(tmp);

    // Llegir IP
    tmp = read_until(fd, '\n');
    if (tmp[strlen(tmp)-1] == '\n') tmp[strlen(tmp)-1] = '\0';
    k->ip = strdup(tmp);
    if (k->ip[strlen(k->ip)-1] == '\r') k->ip[strlen(k->ip)-1] = '\0';
    free(tmp);

    // Llegir port
    tmp = read_until(fd, '\n');
    k->port = atoi(tmp);
    free(tmp);

    // Saltar línia buida després del port
    tmp = read_until(fd, '\n');
    free(tmp);

    // Llegir rutes (altres regnes connectats)
    while (1) {
        char *dest = read_until(fd, ' ');
        if (!dest || strlen(dest) == 0) {
            free(dest);
            break;
        }

        char *ip = read_until(fd, ' ');
        char *port_str = read_until(fd, '\n');

        if (!ip || !port_str) {
            free(dest);
            free(ip);
            free(port_str);
            break;
        }

        // Netejar caràcters sobrants
        if (dest[strlen(dest)-1] == '\n') dest[strlen(dest)-1] = '\0';
        if (ip[strlen(ip)-1] == '\n') ip[strlen(ip)-1] = '\0';
        if (port_str[strlen(port_str)-1] == '\n') port_str[strlen(port_str)-1] = '\0';

        routes = realloc(routes, (n_routes + 1) * sizeof(Route));
        routes[n_routes].dest = strdup(dest);
        routes[n_routes].ip = strdup(ip);
        routes[n_routes].port = atoi(port_str);

        free(dest);
        free(ip);
        free(port_str);

        n_routes++;
    }

    k->routes = routes;
    k->n_routes = n_routes;
}


/***********************************************
*
* @Finalitat: Carrega la llista de productes des d’un fitxer binari.
* @Parametres:
*   - products: punter doble a la llista dinàmica de productes.
*   - fd: descriptor del fitxer obert amb productes.
* @Retorn: nombre total de productes carregats.
*
************************************************/

int getProducts(Product **products, int fd) {
    int n_products = 0;                                                        //Comptador de productes llegits.
    Product tmp;                                                                //Variable temporal per lectura.

    //Bucle de lectura de productes binaris
    while (read(fd, &tmp, sizeof(Product)) == sizeof(Product)) {
        *products = realloc(*products, (n_products + 1) * sizeof(Product));
        (*products)[n_products++] = tmp;
    }
    return n_products;
}

/***********************************************
*
* @Finalitat: Desa la llista de trade a un fitxer dins del directori del regne.
* @Parametres:
*   - ctx: context global amb tota la informació del programa.
*   - path: ruta del directori del regne.
*   - trade_list: llista de productes a desar.
*   - trade_count: nombre de productes a la llista.
* @Retorn: void.
*
************************************************/

void saveList(GlobalContext *ctx, char *path, TradeList *trade_list, int trade_count) {
    if (!ctx || !path || !trade_list || trade_count <= 0)
        return;

    char *full_path = NULL;
    asprintf(&full_path, ".%s", path);


    pid_t pid = fork();

    if (pid < 0) {
        safePrint(ctx, "Error creating process for mkdir.\n");
        return;
    }
    else if (pid == 0) {
        execlp("mkdir", "mkdir", "-p", full_path, NULL);
        
        perror("execlp");
        kill(getpid(), SIGTERM);
    }
    else {
        wait(NULL);
    }

    char *file_path = NULL;
    asprintf(&file_path, ".%s/trade_list.txt", path);

    int fd = open(file_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {

        safePrint(ctx, "Error creating trade list file\n");
        free(file_path);
        return;
    }

    for (int i = 0; i < trade_count; i++) {
        char *buffer;
        int len = asprintf(&buffer, "%s %d\n",
                           trade_list[i].item.name,
                           trade_list[i].amount);
        if (len > 0)
            write(fd, buffer, len);
        free(buffer);
    }

    close(fd);

    free(file_path);
    free(full_path);
}

void create_folder_safe(const char *path) {
    if (!path) return;

    pid_t pid = fork();
    if (pid == 0) {
         execlp("mkdir", "mkdir", "-p", path, NULL);
        
        perror("execlp");
        kill(getpid(), SIGTERM);
    } else if (pid > 0) {
        // Padre: Espera
        wait(NULL);
    }
}


int saveProductsToTempFile(Product *products, int n_products, const char *filename) {
    // 0644 = rw-r--r--
    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return -1;

    for (int i = 0; i < n_products; i++) {
        char *line;
        int len = asprintf(&line, "%d. %s (%d units)\n", i+1, products[i].name, products[i].amount);
        if (len > 0) {
            write(fd, line, len);
            free(line);
        }
    }
    close(fd);
    return 0;
}

// Añadir en persistence.c
int saveTradeListToTempFile(TradeList *list, int count, const char *filename) {
    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return -1;

    for (int i = 0; i < count; i++) {
        char *line;
        // Formato simple: Nombre Cantidad
        int len = asprintf(&line, "%s %d\n", list[i].item.name, list[i].amount);
        if (len > 0) {
            write(fd, line, len);
            free(line);
        }
    }
    close(fd);
    return 0;
}

void update_persistence_stock(GlobalContext *ctx, const char *filename) {

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return;

    for (int i = 0; i < ctx->n_products; i++) {
        write(fd, &ctx->products[i], sizeof(Product));
    }

    close(fd);
}