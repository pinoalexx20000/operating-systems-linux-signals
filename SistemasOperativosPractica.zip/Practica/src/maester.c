/***********************************************
*
* @Proposit: Punt d’entrada principal del programa Maester. S’encarrega d’inicialitzar l’entorn,
*             carregar el regne i els productes, gestionar els senyals i cridar el menú principal.
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#define _GNU_SOURCE
#include "auxiliars.h"
#include "structs.h"
#include "main_controller.h"
#include "trade_controller.h"
#include "persistence.h"
#include <signal.h>
#include <sys/select.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include "network_controller.h"
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "safe_print.h"
#include "envoy_controller.h"

/***********************************************
*
* @Finalitat: Gestiona la rutina d’interrupció SIGINT (^C) per alliberar recursos de manera segura.
* @Parametres: cap.
* @Retorn: void.
*
************************************************/

void handle_SIGINT(void);

/***********************************************
*
* @Finalitat: Defineix el comportament del programa quan rep un senyal del sistema.
* @Parametres:
*   - signum: codi del senyal rebut.
* @Retorn: void.
*
************************************************/

void signal_handler(int signum);

/***********************************************
*
* @Finalitat: Allibera tots els recursos dinàmics.
* @Parametres: cap.
* @Retorn: void.
*
************************************************/

void frees();

/***********************************************
*
* @Finalitat: Punt d’entrada principal. Inicialitza el programa, carrega dades i executa el menú.
* @Parametres:
*   - argc: nombre d’arguments de la línia de comandes.
*   - argv: vector amb els arguments passats al programa.
* @Retorn: 0 si l’execució és correcta, 1 si hi ha errors.
*
************************************************/
GlobalContext ctx;
int pipeCTRLC[2];

int main(int argc, char *argv[]) {
    
    if (initPrint(&ctx) < 0) {
        write(1, "Error: No se pudo inicializar safePrint\n", strlen("Error: No se pudo inicializar safePrint\n"));
        return 1;
    }

    if (argc != 3) {
        safePrint(&ctx, "Uso: ./program maester.dat archivo.db\n");
        return 1;
    }

    int fd_maester = open(argv[1], O_RDONLY);
    int fd_db = open(argv[2], O_RDONLY);
    if (fd_maester < 0 || fd_db < 0) {
        safePrint(&ctx, "Error abriendo archivo\n");
        return 1;
    }

    if (pipe(pipeCTRLC) < 0 || pipe(ctx.pipeServer) < 0) {
        safePrint(&ctx, "Error creando pipe");
        return 1;
    }

    signal(SIGINT, signal_handler);

    if (SEM_constructor(&ctx.ctx_sem) < 0) {
        safePrint(&ctx, "Error creating context semaphore");
        return 1;
    }
    if (SEM_init(&ctx.ctx_sem, 1) < 0) {
        safePrint(&ctx, "Error init context semaphore");
        return 1;
    }
    ctx.ctx_sem_initialized = 1;

    if (SEM_constructor(&ctx.stock_sem) < 0) {
        safePrint(&ctx, "Error creating stock semaphore");
        return 1;
    }
    if (SEM_init(&ctx.stock_sem, 1) < 0) {
        safePrint(&ctx, "Error init stock semaphore");
        return 1;
    }
    ctx.stock_sem_initialized = 1;

    
    getKingdom(&ctx.kingdom, fd_maester);
    ctx.alliances = malloc((ctx.kingdom.n_routes - 1) * sizeof(AllianceRecord));

    for(int i = 1; i < ctx.kingdom.n_routes; i++){
        ctx.alliances[i-1].name = ctx.kingdom.routes[i].dest;
        if(ctx.kingdom.routes[i].port == 0){
            ctx.alliances[i-1].status = UNKNOWN;
            continue;
        }
        
        ctx.alliances[i-1].status = ALLIANCE_NONE;
    }
    ctx.n_allies = ctx.kingdom.n_routes-1;
    ctx.n_products = getProducts(&ctx.products, fd_db);

    close(fd_maester);
    close(fd_db);

    safePrint(&ctx,"\nMaester initialized. The board is set.\n");

    pthread_t server_thread;
    pthread_create(&server_thread, NULL, start_server, &ctx);

    menu_principal(&ctx, pipeCTRLC);
    //Enviar DISCONNECT a aliats

    //Desbloquear thread listener
    //wait pthreadwait()

    pthread_join(server_thread, NULL);

    close(pipeCTRLC[0]); close(pipeCTRLC[1]);
    close(ctx.pipeServer[0]); close(ctx.pipeServer[1]);

    
    shutdown_envoys(&ctx);
    frees();

    return 0;
}

void handle_SIGINT(void) {
    char c = 'x';
    (void)write(pipeCTRLC[1], &c, 1);
}

void signal_handler(int signum) {
    if (signum == SIGINT)handle_SIGINT();
}

void frees(){
    free(ctx.kingdom.name);
    free(ctx.kingdom.path);
    free(ctx.kingdom.ip);
    for(int j = 0; j < ctx.kingdom.n_routes; j++){
        free(ctx.kingdom.routes[j].dest);
        free(ctx.kingdom.routes[j].ip);
    }
    free(ctx.kingdom.routes);
    free(ctx.products);

    if (ctx.alliances) {
        free(ctx.alliances);
        ctx.alliances = NULL;
    }

    if (ctx.main_line) {
        free(ctx.main_line);
        ctx.main_line = NULL;
    }

    if (ctx.trade_line) {
        free(ctx.trade_line);
        ctx.trade_line = NULL;
    }

    if (ctx.trade_list) {
        free(ctx.trade_list);
        ctx.trade_list = NULL;
    }
    if (ctx.ctx_sem_initialized) {
        SEM_destructor(&ctx.ctx_sem);
        ctx.ctx_sem_initialized = 0;
    }
    if (ctx.stock_sem_initialized) {
        SEM_destructor(&ctx.stock_sem);
        ctx.stock_sem_initialized = 0;
    }

    destroyPrint(&ctx);
}
