//************
// Mòdul: auxiliars.c
//************

#define _GNU_SOURCE
#include "auxiliars.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

long get_file_size(const char *filename) {
    struct stat st;
    if (stat(filename, &st) == 0) return st.st_size;
    return -1;
}

// Versión estricta SIN popen/fscanf (System Calls)
void get_md5(const char *filename, char *output_buffer) {
    int p[2];
    if (pipe(p) < 0) { strcpy(output_buffer, "0"); return; }
    
    pid_t pid = fork();
    if (pid == 0) {
        close(p[0]); 
        dup2(p[1], STDOUT_FILENO); // Redirigir stdout al pipe
        close(p[1]);
        
        // Silenciar stderr
        int nullfd = open("/dev/null", O_WRONLY);
        if (nullfd >= 0) { dup2(nullfd, STDERR_FILENO); close(nullfd); }

        execlp("md5sum", "md5sum", filename, NULL);
        exit(1);
    }
    
    close(p[1]);
    
    // Leer salida del pipe
    char tmp[64] = {0};
    read(p[0], tmp, 63); 
    close(p[0]); 
    wait(NULL);
    
    // Parsear solo el hash (hasta el primer espacio)
    for(int i=0; i<32; i++) {
        if(tmp[i] == ' ' || tmp[i] == '\0' || tmp[i] == '\n') { 
            output_buffer[i] = '\0'; 
            break; 
        }
        output_buffer[i] = tmp[i];
    }
    output_buffer[32] = '\0';
}

char* read_until(int fd, char delimiter) {
    char *buffer = NULL;
    char aux;
    int i = 0;

    while (1) {
        if (read(fd, &aux, 1) <= 0) break;
        if (aux == delimiter) break;
        char *tmp = realloc(buffer, i + 1);
        if (!tmp) {
            free(buffer);
            return NULL;
        }
        buffer = tmp;
        buffer[i++] = aux;
    }
    if (buffer == NULL) return NULL;

    buffer = realloc(buffer, i + 1);
    buffer[i] = '\0';
    return buffer;
}

void to_lowercase(char *s) {
    for (int i = 0; s[i]; i++) {
        if (s[i] >= 'A' && s[i] <= 'Z')
            s[i] = s[i] - 'A' + 'a';
    }
}

// Estos helpers de impresión usan asprintf/vasprintf que suelen estar permitidos
// Si te piden estricto write, estos wrappers al final llaman a printStatic que debería usar write.

char* GLOBAL_dynamicFormat(const char* format, ...) {
    va_list args;
    va_start(args, format);
    char* buffer = NULL;
    int length = vasprintf(&buffer, format, args);
    va_end(args);
    if (length < 0) { if(buffer) free(buffer); return NULL; }
    return buffer;
}

void GLOBAL_dynamicPrint(const char* message, ...) {
    va_list args;
    va_start(args, message);
    char* buffer = NULL;
    int length = vasprintf(&buffer, message, args);
    if (length >= 0 && buffer) {
        printStatic(buffer);
    }
    if(buffer) free(buffer);
    va_end(args);
}