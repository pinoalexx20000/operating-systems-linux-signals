/***********************************************
*
* @Proposit: Implementa el control principal del programa, gestionant les ordres d’usuari 
*             i la navegació entre els diferents menús (principal i de comerç).
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#include "main_controller.h"


Product* other_realm_products(){
    int n_other_products = 4;
    Product *other_products = malloc(n_other_products * sizeof(Product));
    if (!other_products) {
        perror("malloc");
        return NULL;
    }

    strcpy(other_products[0].name, "Valyrian Steel Sword");
    other_products[0].amount = 3;
    other_products[0].weight = 12.5;

    strcpy(other_products[1].name, "Dragon Glass Dagger");
    other_products[1].amount = 10;
    other_products[1].weight = 1.2;

    strcpy(other_products[2].name, "Golden Chalice");
    other_products[2].amount = 5;
    other_products[2].weight = 3.4;

    strcpy(other_products[3].name, "Ancient Tome of Spells");
    other_products[3].amount = 2;
    other_products[3].weight = 7.8;

    return other_products;
}

int process_command(GlobalContext *ctx) {

    char *cmd = strtok(ctx->main_line, " ");
    if (!cmd) {
        printStatic(MISS);
        return 0;
    }
    char *buf;
    to_lowercase(cmd);

    // --------------------------------------------------------------------------------
    // COMANDA: LIST
    // --------------------------------------------------------------------------------
    if (strcmp(cmd, CMD_LIST) == 0) {

        char *sub = strtok(NULL, " ");
        if (!sub) {
            printStatic(MISS_LIST);
            return 0;
        }
        to_lowercase(sub);

        if (strcmp(sub, SUB_REALMS) == 0) {
            list_realms(ctx->kingdom);

        } else if (strcmp(sub, SUB_PRODUCTS) == 0) {
            char *realm = strtok(NULL, " ");
            if (!realm) {
                list_local_products(ctx->products, ctx->n_products);
            } else {
                if (!is_allied(ctx, realm)) {
                    asprintf(&buf, "No active alliance with %s. Cannot list products.\n", realm);
                    safePrint(ctx, buf);
                    free(buf);
                    return 0;
                }
            
                if (assign_task_to_envoy(ctx, TASK_LIST_REQ, realm, NULL)) {
                    asprintf(&buf, "Envoy assigned to request products from %s.\n", realm);
                    safePrint(ctx, buf);
                    free(buf);
                } else {
                    printStatic("All envoys are occupied. Your command must wait.\n");
                }

            }
        } else {
            printStatic("Unknown command\n");
        }

    // --------------------------------------------------------------------------------
    // COMANDA: PLEDGE
    // --------------------------------------------------------------------------------
    } else if (strcmp(cmd, CMD_PLEDGE) == 0) {
        char *first = strtok(NULL, " ");
        if (!first) {
            printStatic("Missing arguments. Usage:\n"
                        "  PLEDGE STATUS\n"
                        "  PLEDGE <Realm> <sigil>\n"
                        "  PLEDGE RESPOND <Realm> <ACCEPT/REJECT>\n");
            return 0;
        }

        char first_lower[32];
        strncpy(first_lower, first, sizeof(first_lower) - 1);
        first_lower[sizeof(first_lower) - 1] = '\0';
        to_lowercase(first_lower);

        // --- SUBCOMMAND: RESPOND ---
        if (strcmp(first_lower, SUB_RESPOND) == 0) {
            char *realm = strtok(NULL, " ");
            char *decision = strtok(NULL, " ");
            if (!realm || !decision) {
                printStatic("Missing arguments. Usage: PLEDGE RESPOND <Realm> <ACCEPT/REJECT>\n");
                return 0;
            }

            char decision_upper[8];
            size_t i;
            for (i = 0; i < sizeof(decision_upper) - 1 && decision[i]; ++i)
                decision_upper[i] = (char)toupper((unsigned char)decision[i]);
            decision_upper[i] = '\0';

            if (strncmp(decision_upper, "ACCEPT", 6) != 0 &&
                strncmp(decision_upper, "REJECT", 6) != 0) {
                printStatic("Decision must be ACCEPT or REJECT\n");
                return 0;
            }

            Route *r = find_route_for(ctx, realm);
            if (!r) {
                asprintf(&buf, "No route found for realm '%s'\n", realm);
                safePrint(ctx, buf);
                free(buf);
                return 0;
            }

            // PDF Pag 3 - RESPOSTA A PETICIÓ D'ALIANÇA
            // TYPE: 0x03
            // ORIGIN: IP:Port
            // DATA: <ACCEPT/REJECT>&<RealmName>

            char *data;
            asprintf(&data, "%s&%s", decision_upper, ctx->kingdom.name);
            
            Frame f;
            char *origin_str = get_my_origin(ctx); 
            init_frame(&f, TYPE_RESPONSE, origin_str, realm, data);
            
            free(origin_str);
            free(data);
            asprintf(&buf, "Sent PLEDGE %s to %s with ip: %s\n", decision_upper, realm, r->ip);
            safePrint(ctx, buf);
            free(buf);

            if (send_frame(ctx, r, &f) == 0) {
                if (strncmp(decision_upper, "REJECT", 6) == 0) {
                    asprintf(&buf, "Alliance with %s denied.\n", realm);
                    safePrint(ctx, buf);
                    free(buf);
                    for (int i = 0; i < ctx->n_allies; i++) {
                        if (strcmp(ctx->alliances[i].name, realm) == 0) {
                            ctx->alliances[i].status = ALLIANCE_FAILED;
                            break;
                        }
                    }
                }
            } else {
                asprintf(&buf, "No s'ha pogut enviar la resposta de PLEDGE a %s\n", realm);
                safePrint(ctx, buf);
                free(buf);
            }

        // --- SUBCOMMAND: STATUS ---
        } else if (strcmp(first_lower, SUB_STATUS) == 0){
            int something = 0;
            for(int i = 0; i < ctx->n_allies; i++) {
                if(ctx->alliances[i].status == ALLIANCE_ACTIVE ||
                   ctx->alliances[i].status == ALLIANCE_PENDING || ctx->alliances[i].status == ALLIANCE_FAILED) {
                    something = 1;
                    break;
                }
            }
            if (!something) {
                safePrint(ctx, "You have no pledges awaiting or accepted.");
            } else {
                for(int i = 0; i < ctx->n_allies; i++) {
                asprintf(&buf, " - %s : %s\n", ctx->alliances[i].name, 
                         ctx->alliances[i].status == ALLIANCE_ACTIVE ? "ALLIED" : 
                         (ctx->alliances[i].status == ALLIANCE_PENDING ? "ON_PENDING" : (ctx->alliances[i].status == ALLIANCE_FAILED ? "FAILED" : "PENDING")));
                safePrint(ctx, buf);
                free(buf);
            }
            }
            
            printStatic("\n");

        // --- SUBCOMMAND: REQUEST (PLEDGE <Realm> <Sigil>) ---
        } else {
            char *realm = first;
            char *sigil = strtok(NULL, " ");
            if (!realm || !sigil) {
                printStatic("Missing arguments. Usage: PLEDGE <Realm> <sigil>\n");
                return 0;
            }

            char *buf;
            long filesize = get_file_size(sigil);
            if (filesize < 0) {
                asprintf(&buf, "Error: Could not access file '%s'.\n", sigil);
                safePrint(ctx, buf);
                free(buf);
                return 0;
            }

            char md5[33];
            get_md5(sigil, md5);

            Route *r = find_route_for(ctx, realm);
            if (!r) {
                safePrint(ctx, "No such realm exists. The pledge is hereby withdrawn.\n");
                
                return 0;
            }
            if (assign_task_to_envoy(ctx, TASK_PLEDGE, realm, sigil)) {
                // Si devuelve 1, un Envoy ha aceptado la misión.
                // No imprimimos "Pledge sent" todavía, eso llegará asíncronamente.
                asprintf(&buf, "Envoy assigned to deliver pledge to %s.\n", realm);
                safePrint(ctx, buf);
                free(buf);
                for(int i = 0; i < ctx->n_allies; i++) {
                    if(strcmp(ctx->alliances[i].name, realm) == 0) {
                        ctx->alliances[i].status = ALLIANCE_PENDING;
                        break;
                    }
                }
            } else {
                // Si devuelve 0, todos los emisarios están ocupados (ENVOY_BUSY).
                printStatic("All envoys are busy. Try again later.\n");
            }

        }

    // --------------------------------------------------------------------------------
    // COMANDA: START TRADE
    // --------------------------------------------------------------------------------
    } else if (strcmp(cmd, CMD_START) == 0) {

        char *sub = strtok(NULL, " ");
        if (!sub) {
            safePrint(ctx, MISS_START_TRADE);
            return 0;
        }
        to_lowercase(sub);

        if (strcmp(sub, SUB_TRADE) == 0) {
            char *realm = strtok(NULL, " ");
            if (!realm) {
                safePrint(ctx, MISS_START_TRADE);
            } else {
                if(!is_allied(ctx, realm)) {
                    char *buf;
                    asprintf(&buf, "No active alliance with %s. Cannot start trade.\n", realm);
                    safePrint(ctx, buf);
                    free(buf);
                    return 0;
                }
                // La lógica de tramas de trade se maneja dentro de menu_trade (trade_controller.c)
                menu_trade(ctx, realm);
            }
        } else {
            printStatic("Unknown command\n");
        }

    } else if (strcmp(cmd, CMD_ENVOY) == 0) {
        
        char *sub = strtok(NULL, " ");
        if (!sub) {
            printStatic("Missing arguments. Usage: ENVOY STATUS\n");
            return 0;
        }
        to_lowercase(sub);

        if (strcmp(sub, "status") == 0) {
            
            // Si no hay envoys configurados
            if (!ctx->envoys || ctx->kingdom.envoys == 0) {
                printStatic("No envoys in the council.\n");
                return 0;
            }

            for (int i = 0; i < ctx->kingdom.envoys; i++) {
                if (ctx->envoys[i].status == ENVOY_FREE) {
                    asprintf(&buf, "- Envoy %d: FREE\n", i + 1);
                    safePrint(ctx, buf);
                    free(buf);
                } else {
                    // Traducir el tipo de tarea a texto
                    char *task_name = "UNKNOWN";
                    if (ctx->envoys[i].current_task_type == TASK_PLEDGE) {
                        task_name = "PLEDGE";
                    } else if (ctx->envoys[i].current_task_type == TASK_LIST_REQ) {
                        task_name = "LIST PRODUCTS";
                    } else if (ctx->envoys[i].current_task_type == TASK_START_TRADE) {
                        task_name = "TRADE";
                    }

                    // Obtener nombre del reino (seguro ante NULL)
                    char *target = ctx->envoys[i].waiting_for_realm ? ctx->envoys[i].waiting_for_realm : "Unknown";



                    asprintf(&buf, "- Envoy %d: ON_MISSION (%s to %s)\n", 
                                        i + 1, task_name, target);
                    safePrint(ctx, buf);
                    free(buf);
                }
            }

        } else {
            printStatic("Unknown envoy command.\n");
        }

    } else if (strcmp(cmd, "exit") == 0) {

        printStatic("The Maester of ");
        printStatic(ctx->kingdom.name);
        printStatic("\nsigns off. The ravens rest. \n\n");
        return 1;

    } else {
        printStatic("Unknown command\n");
    }

    return 0;
}

void menu_principal(GlobalContext *ctx, int pipeCTRLC[2]) {
    int finish = 0;
    
    fd_set current_sockets, ready_sockets;

    init_envoys(ctx);

    FD_ZERO(&current_sockets);
    FD_SET(STDIN_FILENO, &current_sockets);
    FD_SET(pipeCTRLC[0], &current_sockets);

    int max_fd = (pipeCTRLC[0] > STDIN_FILENO) ? pipeCTRLC[0] : STDIN_FILENO;

    if (ctx->envoys) {
        for (int i = 0; i < ctx->kingdom.envoys; i++) {
           
            FD_SET(ctx->envoys[i].fd_read, &current_sockets);
            if (ctx->envoys[i].fd_read > max_fd) max_fd = ctx->envoys[i].fd_read;
        }
    }

    printStatic("$ ");

    while (!finish) {
    
        ready_sockets = current_sockets;
        // Select sin timeout, espera indefinidamente
        int activity = select(max_fd + 1, &ready_sockets, NULL, NULL, NULL);

        if (activity < 0) {
            if (errno == EINTR) continue;   // <-- correcto
            safePrint(ctx, ERR_SLCT);
            continue;
        }

        //CTRL-C

        if (FD_ISSET(pipeCTRLC[0], &ready_sockets)) {
            char buff_sig;
            read(pipeCTRLC[0], &buff_sig, 1);

            write(1, "\nUsuario ha apretado ^C\n", strlen("\nUsuario ha apretado ^C\n"));
            write(1, "Exiting program...\n", strlen("Exiting program...\n"));

            finish = 1;
        }

        //INPUT TECLAT
        else if (FD_ISSET(STDIN_FILENO, &ready_sockets)) {
            ctx->main_line = read_until(STDIN_FILENO, '\n');

            if (ctx->main_line) {
                finish = process_command(ctx);
                
                free(ctx->main_line);
                ctx->main_line = NULL;
                
                if (!finish) {
                    printStatic("$ ");
                }
            }
        }
        else {
            check_envoys_response(ctx, &ready_sockets);
        }
    }
    
    // Al salir, notificamos al hilo servidor
    char c = 'x';
    write(ctx->pipeServer[1], &c, 1); 

    // PDF Pag 6 - DESCONNEXIÓ
    // ORIGIN: IP:Port, DATA: DISCONNECT (esto se hace en network_controller.c/send_disconnect)
    send_disconnect(ctx);
}