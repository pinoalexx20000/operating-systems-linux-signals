//************
// 
// Mòdul: network_controller
// Autor: Bruno Xampeny (basat en exemples de Sistemes Operatius - Canaleta)
// 
//************

#include "network_controller.h"
#include <stdarg.h>


/* Variable estática global para acceso desde signal handler */
static GlobalContext *signal_ctx = NULL; // variable NULL

/***********************************************
*
* @Finalitat: Funcio trim_trailing.
* @Parametres: in: s = s.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
static void trim_trailing(char *s) {
    size_t len; // variable len
    if (!s) return;
    len = strlen(s);
    while (len > 0) {
        char c = s[len - 1]; // variable len
        if (c != '\n' && c != '\r' && c != ' ' && c != '\t') break;
        s[--len] = '\0'; // variable len
    }
}

static const char *resolve_name_from_origin(GlobalContext *ctx, const char *origin) {
    char ip[20]; // variable ip
    int port = 0; // variable port
    if (!ctx || !origin) return NULL;
    if (sscanf(origin, "%19[^:]:%d", ip, &port) != 2) return NULL;
    for (int i = 0; i < ctx->kingdom.n_routes; i++) {
        Route *r = &ctx->kingdom.routes[i]; // variable i
        if (!r->dest || strcmp(r->dest, "DEFAULT") == 0) continue;
        if (r->ip && strcmp(r->ip, ip) == 0 && r->port == port) {
            return r->dest; // variable dest
        }
    }
    return NULL; // variable NULL
}



/***********************************************
*
* @Finalitat: Funcio get_my_origin.
* @Parametres: in: ctx = ctx.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
char* get_my_origin(GlobalContext *ctx) {
    char *origin; // variable origin
    if (asprintf(&origin, "%s:%d", ctx->kingdom.ip, ctx->kingdom.port) == -1) {
        return NULL; // variable NULL
    }
    return origin; // variable origin
}

/***********************************************
*
* @Finalitat: Funcio read_exact.
* @Parametres: in: fd = fd.
* in: buf = buf.
* in: count = count.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
ssize_t read_exact(int fd, unsigned char *buf, size_t count) {
    size_t total_read = 0; // variable total_read
    while (total_read < count) {
        ssize_t res = read(fd, buf + total_read, count - total_read);
        if (res <= 0) return res; // Error o EOF
        total_read += res; // variable res
    }
    return total_read; // variable total_read
}


/***********************************************
*
* @Finalitat: Funcio update_route_from_origin.
* @Parametres: in: ctx = ctx.
* in: ally_name = ally_name.
* in: origin_str = origin_str.
* @Retorn: No retorna res.
*
************************************************/
void update_route_from_origin(GlobalContext *ctx, const char *ally_name, const char *origin_str) {
    char ip[20]; // variable ip
    int port = 0; // variable port
    if (sscanf(origin_str, "%19[^:]:%d", ip, &port) == 2) {
        SEM_wait(&ctx->ctx_sem);
        for (int i = 0; i < ctx->kingdom.n_routes; i++) {
            if (ctx->kingdom.routes[i].dest && strcmp(ctx->kingdom.routes[i].dest, ally_name) == 0) {
                if (ctx->kingdom.routes[i].port == 0 ||!ctx->kingdom.routes[i].ip || strcmp(ctx->kingdom.routes[i].ip, "*.*.*.*") == 0) {
                    free(ctx->kingdom.routes[i].ip);
                    ctx->kingdom.routes[i].ip = strdup(ip);
                    ctx->kingdom.routes[i].port = port; // variable port
                }
                break; // variable break
            }
        }
        SEM_signal(&ctx->ctx_sem);
    }
}

/***********************************************
*
* @Finalitat: Funcio is_allied.
* @Parametres: in: ctx = ctx.
* in: realm = realm.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int is_allied(GlobalContext *ctx, const char *realm) {
    if (!realm) return 0;
    int ok = 0; // variable ok
    SEM_wait(&ctx->ctx_sem);
    for (int i = 0; i < ctx->n_allies; i++) {
        if (strcmp(ctx->alliances[i].name, realm) == 0 && ctx->alliances[i].status == ALLIANCE_ACTIVE){
            ok = 1; // variable ok
            break; // variable break
        }
    }
    SEM_signal(&ctx->ctx_sem);
    return ok; // variable ok
}

/***********************************************
*
* @Finalitat: Funcio find_route_for.
* @Parametres: in: ctx = ctx.
* in: dest = dest.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
Route* find_route_for(GlobalContext *ctx, const char *dest) {
    if (!ctx || !dest) return NULL;

    // 1) "Existe el reino" si está en la tabla de rutas (aunque sea *.*.*.*:0)
    int exists = 0; // variable exists
    for (int i = 0; i < ctx->kingdom.n_routes; i++) {
        const char *d = ctx->kingdom.routes[i].dest; // variable dest
        if (!d) continue;
        if (strcmp(d, "DEFAULT") == 0) continue;
        if (strcmp(d, dest) == 0) { exists = 1; break; }
    }
    if (!exists) return NULL;

    // 2) Ruta directa si la tenemos (ip real + port > 0)
    for (int i = 0; i < ctx->kingdom.n_routes; i++) {
        Route *r = &ctx->kingdom.routes[i]; // variable i
        if (r->dest && strcmp(r->dest, dest) == 0 &&
            r->ip && strcmp(r->ip, "*.*.*.*") != 0 &&
            r->port > 0) {
            return r; // variable r
        }
    }

    // 3) Si no, DEFAULT
    for (int i = 0; i < ctx->kingdom.n_routes; i++) {
        if (ctx->kingdom.routes[i].dest &&
            strcmp(ctx->kingdom.routes[i].dest, "DEFAULT") == 0) {
            return &ctx->kingdom.routes[i]; // variable i
        }
    }
    return NULL; // variable NULL
}




// ====================================================================
//                   FUNCIONES DE FASE 3 (SYSTEM CALLS)
// ====================================================================

// --- LIST PRODUCTS (0x12 -> 0x13) ---
/***********************************************
*
* @Finalitat: Funcio send_file_sequence.
* @Parametres: in: ctx = ctx.
* in: route = route.
* in: filepath = filepath.
* in: filename_virtual = filename_virtual.
* in: type_header = type_header.
* in: type_data = type_data.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int send_file_sequence(GlobalContext *ctx, Route *route, const char *filepath, const char *filename_virtual, int type_header, int type_data) {
    long filesize = get_file_size(filepath);
    if (filesize < 0) return -1;
    char md5[33]; get_md5(filepath, md5);

    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(fd < 0) return -1;
    struct sockaddr_in dest; memset(&dest, 0, sizeof(dest));
    dest.sin_family = AF_INET; dest.sin_port = htons(route->port);
    inet_pton(AF_INET, route->ip, &dest.sin_addr);
    
    if (connect(fd, (void*)&dest, sizeof(dest)) < 0) { close(fd); return -1; }

    // 1. Header
    char *data_header; asprintf(&data_header, "%s&%ld&%s", filename_virtual, filesize, md5);
    Frame head_frame; char *my_origin = get_my_origin(ctx);
    init_frame(&head_frame, type_header, my_origin, route->dest, data_header);
    free(data_header); free(my_origin);

    unsigned char buffer[FRAME_SIZE]; // variable FRAME_SIZE
    serialize_frame(&head_frame, buffer);
    write(fd, buffer, FRAME_SIZE);

    // 2. Ack
    if (read_exact(fd, buffer, FRAME_SIZE) <= 0) { close(fd); return -1; }
    Frame ack; deserialize_frame(buffer, &ack);
    if (ack.type != TYPE_ACK) { close(fd); return -1; }

    // 3. Data (OPEN + READ + WRITE)
    int file_fd = open(filepath, O_RDONLY);
    if (file_fd < 0) { close(fd); return -1; }

    char file_buf[DATA_SIZE];  // variable DATA_SIZE
    ssize_t br; // variable br
    while ((br = read(file_fd, file_buf, DATA_SIZE)) > 0) {
        Frame d; memset(&d, 0, sizeof(Frame)); 
        d.type = type_data;  // variable type_data
        d.data_length = br; // variable br
        memcpy(d.data, file_buf, br);
        
        serialize_frame(&d, buffer);
        write(fd, buffer, FRAME_SIZE);
    }
    close(file_fd);

    // 4. Ack MD5
    if (read_exact(fd, buffer, FRAME_SIZE) <= 0) { close(fd); return -1; }
    Frame ackm; deserialize_frame(buffer, &ackm);
    close(fd);

    if (ackm.type == 0x32 && strncmp(ackm.data, "CHECK_OK", 8) == 0) return 1;
    return 0; // variable return
}

/***********************************************
*
* @Finalitat: Funcio send_trade_sequence.
* @Parametres: in: ctx = ctx.
* in: dest_name = dest_name.
* in: dest_ip = dest_ip.
* in: dest_port = dest_port.
* in: filepath = filepath.
* in: filename_virtual = filename_virtual.
* in: resp_out = resp_out.
* in: resp_out_sz = resp_out_sz.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int send_trade_sequence(GlobalContext *ctx, // variable ctx
                        const char* dest_name, const char* dest_ip, int dest_port, // variable dest_port
                        const char *filepath, const char *filename_virtual, // variable filename_virtual
                        char *resp_out, size_t resp_out_sz)
{
    if (!resp_out || resp_out_sz == 0) return -1;
    resp_out[0] = '\0'; // variable resp_out

    long filesize = get_file_size(filepath);
    if (filesize < 0) return -1;

    char md5[33]; // variable md5
    get_md5(filepath, md5);

    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd < 0) return -1;

    struct sockaddr_in dest; // variable dest
    memset(&dest, 0, sizeof(dest));
    dest.sin_family = AF_INET; // variable AF_INET
    dest.sin_port = htons(dest_port);
    if (inet_pton(AF_INET, dest_ip, &dest.sin_addr) != 1) {
        close(fd);
        return -1; // variable return
    }

    if (connect(fd, (void*)&dest, sizeof(dest)) < 0) {
        close(fd);
        return -1; // variable return
    }

    unsigned char buffer[FRAME_SIZE]; // variable FRAME_SIZE

    // --- 0x14 header ---
    char *data_header = NULL; // variable NULL
    if (asprintf(&data_header, "%s&%ld&%s", filename_virtual, filesize, md5) < 0 || !data_header) {
        close(fd);
        return -1; // variable return
    }

    char *my_origin = get_my_origin(ctx);
    if (!my_origin) { free(data_header); close(fd); return -1; }

    Frame head_frame; // variable head_frame
    init_frame(&head_frame, 0x14, my_origin, dest_name, data_header);
    free(data_header);

    serialize_frame(&head_frame, buffer);
    if (write(fd, buffer, FRAME_SIZE) != FRAME_SIZE) { close(fd); free(my_origin); return -1; }

    // esperar 0x31
    if (read(fd, buffer, FRAME_SIZE) != FRAME_SIZE) { close(fd); free(my_origin); return -1; }

    Frame ack; // variable ack
    if (!deserialize_frame(buffer, &ack) || ack.type != 0x31) {
        close(fd);
        free(my_origin);
        return -1; // variable return
    }

    // --- 0x15 data ---
    int file_fd = open(filepath, O_RDONLY);
    if (file_fd < 0) { close(fd); free(my_origin); return -1; }

    char file_buf[DATA_SIZE]; // variable DATA_SIZE
    ssize_t br; // variable br

    while ((br = read(file_fd, file_buf, DATA_SIZE)) > 0) {
        Frame d; // variable d
        memset(&d, 0, sizeof(Frame));
        d.type = 0x15; // variable x15

        // origin/destination
        strncpy(d.origin, my_origin, ORIGIN_SIZE - 1);
        d.origin[ORIGIN_SIZE - 1] = '\0'; // variable ORIGIN_SIZE
        strncpy(d.destination, dest_name, DEST_SIZE - 1);
        d.destination[DEST_SIZE - 1] = '\0'; // variable DEST_SIZE

        d.data_length = (uint16_t)br;
        memcpy(d.data, file_buf, (size_t)br);

        serialize_frame(&d, buffer);
        if (write(fd, buffer, FRAME_SIZE) != FRAME_SIZE) {
            close(file_fd);
            close(fd);
            free(my_origin);
            return -1; // variable return
        }
    }

    close(file_fd);
    free(my_origin);

    // esperar 0x32
    if (read(fd, buffer, FRAME_SIZE) != FRAME_SIZE) { close(fd); return -1; }

    Frame ackm; // variable ackm
    if (!deserialize_frame(buffer, &ackm) || ackm.type != 0x32) {
        close(fd);
        return -1; // variable return
    }
    if (strncmp(ackm.data, "CHECK_OK", 8) != 0) {
        close(fd);
        return 0; // MD5 mismatch
    }

    // --- leer 0x16 (respuesta trade) ---
    if (read(fd, buffer, FRAME_SIZE) != FRAME_SIZE) { close(fd); return -1; }

    Frame resp; // variable resp
    if (!deserialize_frame(buffer, &resp) || resp.type != 0x16) {
        close(fd);
        return -1; // variable return
    }

    // copiar data "OK" o "REJECT&..."
    strncpy(resp_out, resp.data, resp_out_sz - 1);
    resp_out[resp_out_sz - 1] = '\0'; // variable resp_out_sz

    close(fd);
    return 1; // variable return
}


/***********************************************
*
* @Finalitat: Funcio receive_file_sequence.
* @Parametres: in: ctx = ctx.
* in: fd = fd.
* in: header = header.
* in: outfile = outfile.
* @Retorn: No retorna res.
*
************************************************/
void receive_file_sequence(GlobalContext *ctx, int fd, Frame *header, const char *outfile) {
    char dc[DATA_SIZE]; strncpy(dc, header->data, DATA_SIZE);
    char *saveptr; strtok_r(dc, "&", &saveptr); 
    char *fz = strtok_r(NULL, "&", &saveptr); 
    char *md5_exp = strtok_r(NULL, "&", &saveptr);
    long total = atol(fz?fz:"0");

    // Ack OK
    Frame ack; unsigned char buf[FRAME_SIZE]; char *my=get_my_origin(ctx);
    char *ad; asprintf(&ad, "OK&%s", ctx->kingdom.name);
    init_frame(&ack, TYPE_ACK, my, header->origin, ad); free(ad); free(my);
    serialize_frame(&ack, buf); write(fd, buf, FRAME_SIZE);

    // Recibir Data (OPEN + WRITE)
    int file_fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    long recv = 0; int err = 0; // variable err
    
    while(recv < total) {
        if(read_exact(fd, buf, FRAME_SIZE)<=0) { err=1; break; }
        Frame d;  // variable d
        if(!deserialize_frame(buf, &d)) { err=1; break; }
        
        if (file_fd >= 0) write(file_fd, d.data, d.data_length);
        recv += d.data_length; // variable data_length
    }
    if (file_fd >= 0) close(file_fd);

    // Validar y Ack Final
    char md5_loc[33];  // variable md5_loc
    get_md5(outfile, md5_loc);
    Frame ackm;  // variable ackm
    my=get_my_origin(ctx);
    if(!err && md5_exp && strcmp(md5_loc, md5_exp)==0) {
        asprintf(&ad, "CHECK_OK&%s", ctx->kingdom.name);
        init_frame(&ackm, 0x32, my, header->origin, ad);
        
        // Imprimir lista por pantalla (READ + WRITE STDOUT)
        if(header->type == 0x12) {
            const char *from = header->origin; // variable origin

            char ip[20] = {0}; // variable ip
            int port = 0; // variable port

            if (sscanf(header->origin, "%19[^:]:%d", ip, &port) == 2) {
                for (int i = 0; i < ctx->kingdom.n_routes; i++) {
                    if (ctx->kingdom.routes[i].ip &&
                        strcmp(ctx->kingdom.routes[i].ip, ip) == 0 &&
                        ctx->kingdom.routes[i].port == port && strcmp(ctx->kingdom.routes[i].dest, "DEFAULT") != 0) {
                        from = ctx->kingdom.routes[i].dest; // nombre del reino
                        break; // variable break
                    }
                }
            }

            safePrint(ctx, "\nListing from ");
            safePrint(ctx, from);
            safePrint(ctx, ":\n");
            int fd_list = open(outfile, O_RDONLY);
            if (fd_list >= 0) {
                char line_buf[1024]; // variable line_buf
                ssize_t n; // variable n
                while((n = read(fd_list, line_buf, sizeof(line_buf))) > 0) {
                    write(STDOUT_FILENO, line_buf, n);
                }
                close(fd_list);
            }
            printStatic("\n$ ");
        }
    } else {
        asprintf(&ad, "CHECK_KO&%s", ctx->kingdom.name);
        init_frame(&ackm, 0x32, my, header->origin, ad);
    }
    free(ad); 
    free(my);
    serialize_frame(&ackm, buf); write(fd, buf, FRAME_SIZE);
}

// --- PLEDGE FLOW (0x01 -> 0x02) ---

/***********************************************
*
* @Finalitat: Funcio send_pledge_flow.
* @Parametres: in: fd = fd.
* in: header_frame = header_frame.
* in: filepath = filepath.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int send_pledge_flow(int fd, Frame *header_frame, const char *filepath) {
    unsigned char buffer[FRAME_SIZE]; // variable FRAME_SIZE
    
    serialize_frame(header_frame, buffer);
    write(fd, buffer, FRAME_SIZE);

    if (read_exact(fd, buffer, FRAME_SIZE) <= 0) return 0;
    Frame ack; deserialize_frame(buffer, &ack);
    if (ack.type != TYPE_ACK || strncmp(ack.data, "OK", 2) != 0) return 0;

    // Enviar Imagen (OPEN + READ)
    int file_fd = open(filepath, O_RDONLY);
    if (file_fd < 0) return 0;
    
    char file_buf[DATA_SIZE]; ssize_t br; // variable br
    while ((br = read(file_fd, file_buf, DATA_SIZE)) > 0) {
        Frame d; memset(&d, 0, sizeof(Frame));
        d.type = TYPE_SIGIL_ENV; d.data_length = br; // variable br
        memcpy(d.data, file_buf, br);
        serialize_frame(&d, buffer); write(fd, buffer, FRAME_SIZE);
    }
    close(file_fd);

    if (read_exact(fd, buffer, FRAME_SIZE) <= 0) return 0;
    Frame ackm;  // variable ackm
    deserialize_frame(buffer, &ackm);
    
    if (ackm.type == 0x32 && strncmp(ackm.data, "CHECK_OK", 8) == 0) return 1;
    return 0; // variable return
}

/***********************************************
*
* @Finalitat: Funcio receive_pledge_flow.
* @Parametres: in: ctx = ctx.
* in: fd = fd.
* in: header_frame = header_frame.
* @Retorn: No retorna res.
*
************************************************/
void receive_pledge_flow(GlobalContext *ctx, int fd, Frame *header_frame) {
    char dc[DATA_SIZE]; strncpy(dc, header_frame->data, DATA_SIZE);
    char *saveptr; // variable saveptr
    char *sender = strtok_r(dc, "&", &saveptr);
    char *fname  = strtok_r(NULL, "&", &saveptr);
    char *fsize  = strtok_r(NULL, "&", &saveptr);
    char *md5_exp= strtok_r(NULL, "&", &saveptr);
    long total = atol(fsize?fsize:"0");
    
    char *folder_path = NULL; // variable NULL
    char *path_config = ctx->kingdom.path; // variable path
    
    if(path_config && path_config[0] == '/') path_config++;
    if(!path_config || strlen(path_config)==0) path_config = "downloads";
    
    asprintf(&folder_path, ".%s%s", (path_config[0] == '/') ? "" : "/", path_config);

    create_folder_safe(folder_path);

    char outfile[512]; // variable outfile
    if (sender && fname) snprintf(outfile, 512, "%s/%s_%s", folder_path, sender, fname);
/***********************************************
*
* @Finalitat: Funcio snprintf.
* @Parametres: in: outfile = outfile.
* in: 512 = 512.
* in: "%s/unknown_sigil.png" = "%s/unknown_sigil.png".
* in: folder_path = folder_path.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
    else snprintf(outfile, 512, "%s/unknown_sigil.png", folder_path);
    free(folder_path);

    // Enviar ACK 0x31
    Frame ack; unsigned char buf[FRAME_SIZE]; char *my=get_my_origin(ctx);
    char *ad; asprintf(&ad, "OK&%s", ctx->kingdom.name);
    init_frame(&ack, TYPE_ACK, my, header_frame->origin, ad);
    serialize_frame(&ack, buf); write(fd, buf, FRAME_SIZE);
    free(ad); free(my);

    // Recibir Datos (OPEN + WRITE)
    int file_fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    
    long recv = 0; int err = 0; // variable err
    while(recv < total) {
        if(read_exact(fd, buf, FRAME_SIZE)<=0) { err=1; break; }
        
        Frame d;  // variable d
        if (!deserialize_frame(buf, &d)) { err=1; break; }
        if(d.type != TYPE_SIGIL_ENV) { err=1; break; }
        
        if (file_fd >= 0) write(file_fd, d.data, d.data_length);
        recv += d.data_length; // variable data_length
    }
    if(file_fd >= 0) close(file_fd);

    // Validar MD5
    char md5_loc[33];  // variable md5_loc
    if(file_fd >= 0) get_md5(outfile, md5_loc);

/***********************************************
*
* @Finalitat: Funcio strcpy.
* @Parametres: in: md5_loc = md5_loc.
* in: "ERROR" = "ERROR".
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
    else strcpy(md5_loc, "ERROR");

    Frame ackm; my=get_my_origin(ctx);
    if (!err && md5_exp && strcmp(md5_loc, md5_exp) == 0) {
        asprintf(&ad, "CHECK_OK&%s", ctx->kingdom.name);
    } else {
        asprintf(&ad, "CHECK_KO&%s", ctx->kingdom.name);
        safePrint(ctx, "Error: Sigil corrupted\n");
    }
    init_frame(&ackm, 0x32, my, header_frame->origin, ad);
    serialize_frame(&ackm, buf); write(fd, buf, FRAME_SIZE);
    free(ad); free(my);
}

/***********************************************
*
* @Finalitat: Funcio proxy_pledge_flow.
* @Parametres: in: fd_prev = fd_prev.
* in: fd_next = fd_next.
* in: header_frame = header_frame.
* @Retorn: No retorna res.
*
************************************************/
void proxy_pledge_flow(int fd_prev, int fd_next, Frame *header_frame) {
    unsigned char buf[FRAME_SIZE]; // variable FRAME_SIZE
    serialize_frame(header_frame, buf); write(fd_next, buf, FRAME_SIZE);
    
    if(read_exact(fd_next, buf, FRAME_SIZE) <= 0) return;
    write(fd_prev, buf, FRAME_SIZE); 

    char dc[DATA_SIZE]; strncpy(dc, header_frame->data, DATA_SIZE);
    char *sp; strtok_r(dc, "&", &sp); strtok_r(NULL, "&", &sp); 
    char *fs = strtok_r(NULL, "&", &sp);
    long total = atol(fs?fs:"0");
    long fwd = 0; // variable fwd

    while(fwd < total) {
        if(read_exact(fd_prev, buf, FRAME_SIZE) <= 0) break;
        write(fd_next, buf, FRAME_SIZE);
        Frame d; deserialize_frame(buf, &d);
        fwd += d.data_length; // variable data_length
    }
    if(read_exact(fd_next, buf, FRAME_SIZE) > 0) {
        write(fd_prev, buf, FRAME_SIZE);
    }
}

/***********************************************
*
* @Finalitat: Funcio open_listen_socket.
* @Parametres: in: ip = ip.
* in: port = port.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int open_listen_socket(const char *ip, int port) {
    struct sockaddr_in s_addr; // variable s_addr
    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(fd<0) return ERR_CODE_SOCKET;
    int opt=1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    memset(&s_addr,0,sizeof(s_addr)); s_addr.sin_family=AF_INET; s_addr.sin_port=htons(port);
    inet_pton(AF_INET, ip, &s_addr.sin_addr);
    if(bind(fd, (void*)&s_addr, sizeof(s_addr)) < 0) { close(fd); return ERR_CODE_SOCKET; }
    listen(fd, 10);
    return fd; // variable fd
}

/***********************************************
*
* @Finalitat: Funcio start_server.
* @Parametres: in: args = args.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
void* start_server(void* args) {
    GlobalContext* ctx = (GlobalContext*) args;
    signal_ctx = ctx; // variable ctx
    int server_fd = open_listen_socket(ctx->kingdom.ip, ctx->kingdom.port);
    if(server_fd == ERR_CODE_SOCKET) {
        printStaticFd(2, "ERROR: no s'ha pogut iniciar el servidor\n");
        return NULL; // variable NULL
    }
    int running = 1; // variable running
    fd_set readfds; // variable readfds
    int max_fd = (server_fd > ctx->pipeServer[0]) ? server_fd : ctx->pipeServer[0];

    while (running) {
        FD_ZERO(&readfds); FD_SET(server_fd, &readfds); FD_SET(ctx->pipeServer[0], &readfds);
        if (select(max_fd + 1, &readfds, NULL, NULL, NULL) < 0 && errno!=EINTR) continue;
        if (FD_ISSET(ctx->pipeServer[0], &readfds)) { char c; read(ctx->pipeServer[0],&c,1); running=0; }
        if (running && FD_ISSET(server_fd, &readfds)) {
            int fd = accept(server_fd, NULL, NULL);
            if(fd>=0) {
                pthread_t t; ClientHandlerArgs* a=malloc(sizeof(ClientHandlerArgs));
                a->fd_client=fd; a->ctx=ctx; // variable ctx
                pthread_create(&t,NULL,handle_incoming_message,a);
                pthread_detach(t);
            }
        }
    }
    close(server_fd);
    return NULL; // variable NULL
}

/***********************************************
*
* @Finalitat: Funcio process_received_order.
* @Parametres: in: ctx = ctx.
* in: filename = filename.
* in: reason_out = reason_out.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int process_received_order(GlobalContext *ctx, const char *filename, char *reason_out) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        strcpy(reason_out, "INTERNAL_ERROR");
        return -1; // variable return
    }

    SEM_wait(&ctx->stock_sem);

    char *line; // variable line
    // VUELTA 1: VALIDACIÓN
    while ((line = read_until(fd, '\n')) != NULL) {
        if (strlen(line) == 0) { free(line); continue; }
        
        char *last_space = strrchr(line, ' ');
        if (!last_space) { free(line); continue; }
        
        *last_space = '\0'; // variable last_space
        char *prod_name = line; // variable line
        long qty_requested = strtol(last_space + 1, NULL, 10);

        int found = 0; // variable found
        for (int i = 0; i < ctx->n_products; i++) {
            char name_stock[100]; char name_req[100]; // variable name_req
            strncpy(name_stock, ctx->products[i].name, 99); name_stock[99]=0;
            strncpy(name_req, prod_name, 99); name_req[99]=0;
            to_lowercase(name_stock); to_lowercase(name_req);

            if (strcmp(name_stock, name_req) == 0) {
                found = 1; // variable found
                if (ctx->products[i].amount < qty_requested) {
                    sprintf(reason_out, "OUT_OF_STOCK (%s)", ctx->products[i].name);
                    free(line); close(fd); SEM_signal(&ctx->stock_sem); return -1;
                }
                break; // variable break
            }
        }
        if (!found) {
            sprintf(reason_out, "UNKNOWN_PRODUCT (%s)", prod_name);
            free(line); close(fd); SEM_signal(&ctx->stock_sem); return -1;
        }
        free(line);
    }

    // VUELTA 2: ACTUALIZACIÓN
    lseek(fd, 0, SEEK_SET);
    while ((line = read_until(fd, '\n')) != NULL) {
        if (strlen(line) == 0) { free(line); continue; }
        char *last_space = strrchr(line, ' ');
        if (!last_space) { free(line); continue; }
        *last_space = '\0'; // variable last_space
        char *prod_name = line; // variable line
        long qty_requested = strtol(last_space + 1, NULL, 10);

        for (int i = 0; i < ctx->n_products; i++) {
            char name_stock[100]; char name_req[100]; // variable name_req
            strncpy(name_stock, ctx->products[i].name, 99); name_stock[99]=0;
            strncpy(name_req, prod_name, 99); name_req[99]=0;
            to_lowercase(name_stock); to_lowercase(name_req);

            if (strcmp(name_stock, name_req) == 0) {
                ctx->products[i].amount -= qty_requested; // variable qty_requested
                break; // variable break
            }
        }
        free(line);
    }
    close(fd);

    // Persistencia
    update_persistence_stock(ctx, "stock_updated.db"); // O usa el nombre real si lo tienes
    SEM_signal(&ctx->stock_sem);
    return 0; // variable return
}

/***********************************************
*
* @Finalitat: Funcio handle_incoming_message.
* @Parametres: in: args = args.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
void* handle_incoming_message(void* args) {
    ClientHandlerArgs* ca = (ClientHandlerArgs*)args;
    int fd = ca->fd_client; // variable fd_client
    GlobalContext* ctx = ca->ctx; // variable ctx
    free(ca);

    unsigned char buffer[FRAME_SIZE]; // variable FRAME_SIZE
    if (read_exact(fd, buffer, FRAME_SIZE) <= 0) { close(fd); return NULL; }

    Frame f; // variable f
    if(!deserialize_frame(buffer, &f)) { 
        Frame nack; unsigned char nb[FRAME_SIZE]; char *my=get_my_origin(ctx);
        init_frame(&nack, TYPE_NACK, my?my:"", f.origin, "BAD_CHECKSUM");
        if(my){
            free(my); 
            serialize_frame(&nack, nb);
        } 
        write(fd, nb, FRAME_SIZE);
        close(fd); return NULL; 
    }

    if (f.type == TYPE_ACK) { 
        // DATA esperado: "OK&<NombreEmisor>"
        char dc[DATA_SIZE];  // variable DATA_SIZE
        strncpy(dc, f.data, DATA_SIZE);
        
        char *prefix = strtok(dc, "&");
        char *sender_name = strtok(NULL, "&");
        char *buf; // variable buf

        if (prefix && sender_name && strcmp(prefix, "OK") == 0) {
            asprintf(&buf, "Alliance with %s established.\n", sender_name);
            safePrint(ctx, buf);
            free(buf);
            
            // Actualizamos el estado de PENDING a ACTIVE
            SEM_wait(&ctx->ctx_sem);
            for(int i=0; i<ctx->n_allies; i++) {
                if(strcmp(ctx->alliances[i].name, sender_name) == 0) {
                    // Solo activamos si no estaba ya fallida
                    if (ctx->alliances[i].status != ALLIANCE_FAILED) {
                        ctx->alliances[i].status = ALLIANCE_ACTIVE; // variable ALLIANCE_ACTIVE
                    }
                    break; // variable break
                }
            }
            SEM_signal(&ctx->ctx_sem);
        }
        close(fd);
        return NULL; // variable NULL

    } else if (f.type == TYPE_NACK) {
        char dc[DATA_SIZE];  // variable DATA_SIZE
        strncpy(dc, f.data, DATA_SIZE);
        
        char *sender_name = dc; // variable dc
        char *buf; // variable buf

        SEM_wait(&ctx->ctx_sem);
        for(int i=0; i<ctx->n_allies; i++) {
            if(strcmp(ctx->alliances[i].name, sender_name) == 0 && ctx->alliances[i].status == ALLIANCE_PENDING) {
                ctx->alliances[i].status = ALLIANCE_FAILED; // variable ALLIANCE_FAILED
                asprintf(&buf, ">>> Timeout received from %s. Alliance FAILED.\n$ ", sender_name);
                safePrint(ctx, buf);
                free(buf);
                break; // variable break
            }
        }
        SEM_signal(&ctx->ctx_sem);
        close(fd);
        return NULL; // variable NULL
    } 

    int is_final = (strcmp(f.destination, ctx->kingdom.name) == 0);
    char *buf; // variable buf

    if (!is_final) {
        Route *r = find_route_for(ctx, f.destination);
        if (!r) {
            asprintf(&buf, ">>> No route for '%s'. Dropping.\n", f.destination);
            safePrint(ctx, buf); free(buf);
            close(fd); return NULL;
        }
        asprintf(&buf, ">>> Recieved hop: %s -> %s\n", f.origin, f.destination);
        safePrint(ctx, buf); free(buf);
        asprintf(&buf, "Found route: %s -> %s:%d\n", r->dest, r->ip, r->port);
        safePrint(ctx, buf); free(buf);
        safePrint(ctx, "Forwarding...\n$ ");

        if (f.type == TYPE_PLEDGE_REQ) {
            int fd_next = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            struct sockaddr_in dest; memset(&dest,0,sizeof(dest));
            dest.sin_family=AF_INET; dest.sin_port=htons(r->port);
            inet_pton(AF_INET, r->ip, &dest.sin_addr);
            if (connect(fd_next, (void*)&dest, sizeof(dest)) == 0) {
                proxy_pledge_flow(fd, fd_next, &f); close(fd_next);
            }
        } else {
            send_frame(ctx, r, &f);
        }
        close(fd); return NULL;
    }

    if (f.type == TYPE_PLEDGE_REQ) {
        receive_pledge_flow(ctx, fd, &f);
        char dc[DATA_SIZE]; strncpy(dc, f.data, DATA_SIZE);
        char *sn = strtok(dc, "&"); 
        if (sn) {
            asprintf(&buf, ">>> Alliance request received from %s.\n", sn);
            safePrint(ctx, buf); free(buf);
            update_route_from_origin(ctx, sn, f.origin);
            
            SEM_wait(&ctx->ctx_sem);
            for(int i=0; i<ctx->n_allies; i++) {
                if(strcmp(ctx->alliances[i].name, sn)==0) {
                    ctx->alliances[i].status = ALLIANCE_PENDING; // variable ALLIANCE_PENDING
                    ctx->alliances[i].requested_at = time(NULL);
                    break; // variable break
                }
            }
            SEM_signal(&ctx->ctx_sem);
        }
        printStatic("$ ");

    } else if (f.type == TYPE_RESPONSE) {
        char dc[DATA_SIZE]; // variable DATA_SIZE
        strncpy(dc, f.data, DATA_SIZE);
        dc[DATA_SIZE - 1] = '\0'; // variable DATA_SIZE

        char *dec  = strtok(dc, "&"); 
        char *name = strtok(NULL, "&");   // name = reino que responde (ej. "E")
        if (dec) trim_trailing(dec);
        if (name) trim_trailing(name);

        const char *resolved = name; // variable name
        if (!resolved || resolved[0] == '\0') {
            resolved = resolve_name_from_origin(ctx, f.origin);
        }

        if (dec && resolved) {

            update_route_from_origin(ctx, resolved, f.origin);
            notify_envoy_response(ctx, resolved, dec, f.origin);

            SEM_wait(&ctx->ctx_sem);
            for (int i = 0; i < ctx->n_allies; i++) {
                if (strcmp(ctx->alliances[i].name, resolved) == 0) {
                    if (strcmp(dec, "ACCEPT") == 0) ctx->alliances[i].status = ALLIANCE_ACTIVE;
                    else ctx->alliances[i].status = ALLIANCE_FAILED; // variable ALLIANCE_FAILED
                    break; // variable break
                }
            }
            SEM_signal(&ctx->ctx_sem);
        } else {
            asprintf(&buf, ">>> Malformed response received from %s.\n", f.origin);
            safePrint(ctx, buf); free(buf);
        }
    } else if (f.type == TYPE_LIST_PRODUCTS_REQ) {
        char realm[DATA_SIZE]; strncpy(realm, f.data, DATA_SIZE);
        if (!is_allied(ctx, realm)) {
            // NACK logic
        } else {
            asprintf(&buf, ">>> Trade request received from %s.\n", realm);
            safePrint(ctx, buf); free(buf);
            saveProductsToTempFile(ctx->products, ctx->n_products, "temp_send.txt");
            Route *r = find_route_for(ctx, realm);
            if(r) {
                safePrint(ctx, "Sending products...\n");
                send_file_sequence(ctx, r, "temp_send.txt", "products.db", 0x12, 0x13);
                safePrint(ctx, "Products sent.\n$ ");
                unlink("temp_send.txt");
            }
        }

    } else if (f.type == TYPE_LIST_PRODUCTS_RESP) {
        // HEADER RESPUESTA LISTA (Recibimos el catálogo)
        safePrint(ctx, "Receiving product list...\n");
        
        // 1. Determinar nombre del fichero: "catalog_<RealmName>.txt"
        // El nombre del reino viene en f.origin? NO, f.origin es IP:Port.
        // Pero en la trama 0x12 (Response), el Sender debería ser capaz de identificarse
        // O bien buscamos en nuestra tabla de rutas quién tiene esa IP.
        
        char *sender_name = "Unknown"; // variable sender_name
        char ip[20]; int port; // variable port
        int found_name = 0; // variable found_name
        
        if (sscanf(f.origin, "%19[^:]:%d", ip, &port) == 2) {
            SEM_wait(&ctx->ctx_sem);
            for(int r=0; r<ctx->kingdom.n_routes; r++) {
                if(ctx->kingdom.routes[r].ip && 
                   strcmp(ctx->kingdom.routes[r].ip, ip)==0 && 
                   ctx->kingdom.routes[r].port==port && strcmp(ctx->kingdom.routes[r].dest, "DEFAULT")!=0) {
                    sender_name = ctx->kingdom.routes[r].dest; // variable dest
                    found_name = 1; // variable found_name
                    break; // variable break
                }
            }
            SEM_signal(&ctx->ctx_sem);
        }
        
        // Si no encontramos el nombre por IP, usamos "received_list.txt" (fallback)
        // Pero para que START TRADE funcione, necesitamos el nombre.
        char *filename = NULL; // variable NULL
        int filename_alloc = 0; // variable filename_alloc

        if (found_name) {
            if (asprintf(&filename, ".%s/catalog_%s.txt", ctx->kingdom.path, sender_name) < 0 || !filename) {
                filename = (char*)"received_list.txt";   // fallback
                filename_alloc = 0; // variable filename_alloc
            } else {
                filename_alloc = 1; // variable filename_alloc
            }
        } else {
            filename = (char*)"received_list.txt";
            filename_alloc = 0; // variable filename_alloc
        }

        receive_file_sequence(ctx, fd, &f, filename);

        if (filename_alloc) free(filename);
        
        // 3. Ya no lo borramos (unlink). Lo dejamos guardado para el TRADE.
        // Solo lo mostramos por pantalla si quieres feedback inmediato.
        // (receive_file_sequence ya lo imprime).
        
        // Si quieres, fuerza un unlink del anterior si existía para limpiar, 
        // pero receive_file_sequence usa O_TRUNC así que sobreescribe.
    } else if (f.type == TYPE_SHOPPING_HEADER) { 
        // HEADER: FileName&Size&MD5
        safePrint(ctx, "Receiving shopping list...\n");
        
        // 1. Recibir el fichero
        receive_file_sequence(ctx, fd, &f, "received_order.txt");
        
        char reason[100]; // variable reason
        char response_data[128]; // variable response_data
        
        char *sender_name = "Unknown"; // variable sender_name
        char ip[20]; int port; // variable port
        if (sscanf(f.origin, "%19[^:]:%d", ip, &port) == 2) {
            for(int i=0; i<ctx->kingdom.n_routes; i++) {
                if (ctx->kingdom.routes[i].ip &&
                    strcmp(ctx->kingdom.routes[i].ip, ip) == 0 &&
                    ctx->kingdom.routes[i].port == port &&
                    ctx->kingdom.routes[i].dest &&
                    strcmp(ctx->kingdom.routes[i].dest, "DEFAULT") != 0) {
                    sender_name = ctx->kingdom.routes[i].dest; // variable dest
                    break; // variable break
                }
            }
        }

        char *buf; // variable buf
        asprintf(&buf, ">>> Trade request received from %s.\n", sender_name);
        safePrint(ctx, buf); free(buf);


        if (process_received_order(ctx, "received_order.txt", reason) == 0) {
            safePrint(ctx, "Order processed successfully. Stock updated.\n");
            strcpy(response_data, "OK");
        } else {
            asprintf(&buf, "Order rejected: %s\n", reason);
            safePrint(ctx, buf); free(buf);
            snprintf(response_data, 128, "REJECT&%s", reason);
        }
        
        // 3. Enviar Respuesta (0x16)
        Frame resp;  // variable resp
        unsigned char b[FRAME_SIZE];  // variable FRAME_SIZE
        char *my = get_my_origin(ctx);
        
        // El destino es el nombre del que pidió
        init_frame(&resp, 0x16, my, sender_name, response_data);
        serialize_frame(&resp, b);
        write(fd, b, FRAME_SIZE);
        
        free(my);
        unlink("received_order.txt");

    // 7. RESPUESTA DE COMANDA (Recibimos confirmación de nuestro pedido)
    } else if (f.type == TYPE_SHOPPING_RESPONSE) {
        // DATA: OK o REJECT&reason
        char dc[DATA_SIZE]; strncpy(dc, f.data, DATA_SIZE);
        
        // Necesitamos saber quién nos responde para despertar al Envoy correcto
        char *sender_name = NULL; // variable NULL
        char ip[20]; int port; // variable port
        
        // Búsqueda inversa IP -> Nombre
        if (sscanf(f.origin, "%19[^:]:%d", ip, &port) == 2) {
            for(int i=0; i<ctx->kingdom.n_routes; i++) {
                if (ctx->kingdom.routes[i].ip && strcmp(ctx->kingdom.routes[i].ip, ip) == 0 && ctx->kingdom.routes[i].port == port) {
                    sender_name = ctx->kingdom.routes[i].dest; // variable dest
                    break; // variable break
                }
            }
        }
        
        if (sender_name) {
            // Despertamos al Envoy que estaba esperando a este reino
            notify_envoy_response(ctx, sender_name, dc, f.origin);
        } else {
            safePrint(ctx, "WARN: Received trade response from unknown origin.\n");
        }
    } else if (f.type == TYPE_DISCONNECT) {
        char ip[20]; int port = 0; int found = 0; // variable found
        if (sscanf(f.origin, "%19[^:]:%d", ip, &port) == 2) {
            for(int i = 0; i < ctx->kingdom.n_routes; i++) {
                if (ctx->kingdom.routes[i].ip && strcmp(ctx->kingdom.routes[i].ip, ip) == 0 && ctx->kingdom.routes[i].port == port) {
                    char *ally = ctx->kingdom.routes[i].dest; // variable dest
                    for(int k=0; k<ctx->n_allies; k++) {
                        if(strcmp(ctx->alliances[k].name, ally) == 0) {
                            ctx->alliances[k].status = ALLIANCE_FAILED; found = 1; break; // variable break
                        }
                    }
                    if(found) { asprintf(&buf, ">>> Ally '%s' signed off.\n", ally); safePrint(ctx, buf); free(buf); }
                }
            }
        }
        if (!found) { asprintf(&buf, ">>> Disconnect from %s.\n", f.origin); safePrint(ctx, buf); free(buf); }

    } else if (f.type == 0x21) {
        safePrint(ctx, ">>> Error: Realm Unreachable (0x21).\n$ ");
    } else if (f.type == 0x25) {
        safePrint(ctx, ">>> Error: Not Authorized (0x25).\n$ ");
    }


    close(fd);
    return NULL; // variable NULL
}

/***********************************************
*
* @Finalitat: Funcio send_frame.
* @Parametres: in: ctx = ctx.
* in: route = route.
* in: f = f.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int send_frame(GlobalContext* ctx, Route* route, Frame* f) {

    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(fd<0) {
        safePrint(ctx,"Socket creation failed");
        return -1; // variable return
    }

    struct sockaddr_in dest;  // variable dest
    memset(&dest,0,sizeof(dest));
    dest.sin_family=AF_INET;  // variable AF_INET
    dest.sin_port=htons(route->port);
    
    if (inet_pton(AF_INET, route->ip, &dest.sin_addr) <= 0) {
        close(fd); return -1;
    }

    if(connect(fd,(void*)&dest,sizeof(dest))<0) { 
        safePrint(ctx,"Connect failed");
        close(fd); return -1; 
    }
    
    

    if (f->type == TYPE_PLEDGE_REQ) {
        char dc[DATA_SIZE]; strncpy(dc, f->data, DATA_SIZE);
        char *sn = strtok(dc, "&"); char *img = strtok(NULL, "&");
        
        if(sn && strcmp(sn, ctx->kingdom.name) == 0) {
            if (send_pledge_flow(fd, f, img)) {
            } else {
                 close(fd); return -1; 
            }
        } else {
            unsigned char b[FRAME_SIZE];  // variable FRAME_SIZE
            serialize_frame(f, b); 
            write(fd, b, FRAME_SIZE);
        }
    } else {
        unsigned char b[FRAME_SIZE];  // variable FRAME_SIZE
        serialize_frame(f, b); 
        write(fd, b, FRAME_SIZE);
    }
    close(fd);
    return 0; // variable return
}

/***********************************************
*
* @Finalitat: Funcio send_disconnect.
* @Parametres: in: ctx = ctx.
* @Retorn: No retorna res.
*
************************************************/
void send_disconnect(GlobalContext* ctx) {
    for(int i=0; i<ctx->kingdom.n_routes; i++) {
        Route *r = &ctx->kingdom.routes[i]; // variable i
        if(!r->dest || strcmp(r->dest,"DEFAULT")==0) continue;
        if(!is_allied(ctx, r->dest)) continue;
        if(!r->ip || strcmp(r->ip,"*.*.*.*")==0) continue;
        
        Frame f; char *my=get_my_origin(ctx);
        init_frame(&f, TYPE_DISCONNECT, my, r->dest, "DISCONNECT");
        free(my); send_frame(ctx, r, &f);
    }
}
