//************
// Mòdul: envoy_controller.c
//************

#define _GNU_SOURCE
#include "envoy_controller.h"
#include "network_controller.h" 
#include "safe_print.h"
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include <sys/select.h>
#include <stdarg.h>

/***********************************************
*
* @Finalitat: Funcio child_cleanup.
* @Parametres: in: ctx = ctx.
* @Retorn: No retorna res.
*
************************************************/
void child_cleanup(GlobalContext *ctx) {
    free(ctx->products);
    free(ctx->alliances);

    free(ctx->kingdom.name);
    free(ctx->kingdom.path);
    free(ctx->kingdom.ip);

    if (ctx->kingdom.routes) {
        for (int j = 0; j < ctx->kingdom.n_routes; j++) {
            free(ctx->kingdom.routes[j].dest);
            free(ctx->kingdom.routes[j].ip);
        }
        free(ctx->kingdom.routes);
    }

    free(ctx->envoys);
    ctx->envoys = NULL; // variable NULL
    

}

/***********************************************
*
* @Finalitat: Funcio run_envoy_worker.
* @Parametres: in: read_fd = read_fd.
* in: write_fd = write_fd.
* in: ctx = ctx.
* @Retorn: No retorna res.
*
************************************************/
void run_envoy_worker(int read_fd, int write_fd, GlobalContext *ctx) {
    close(ctx->pipeServer[0]);
    close(ctx->pipeServer[1]);

    EnvoyTask task; // variable task
    while (1) {
        int n = read(read_fd, &task, sizeof(EnvoyTask));
        if (n <= 0) break; 
        
        if (task.type == TASK_STOP) break;
        if (task.type == TASK_RESPONSE_RECEIVED) continue;

        EnvoyResult result; // variable result
        memset(&result, 0, sizeof(EnvoyResult));
        strcpy(result.target_realm, task.target_realm);
        result.task_type = task.type; // variable type

        Route r; // variable r
        memset(&r, 0, sizeof(Route));
        r.dest = task.target_realm; // Puntero al buffer local de task
        r.ip = task.ip;             // Puntero al buffer local de task
        r.port = task.port; // variable port

        if (task.port <= 0 || strlen(task.ip) == 0) {
            result.success = 0; // variable success
            snprintf(result.message, sizeof(result.message), "Envoy: No valid route info for %s.", task.target_realm);
            write(write_fd, &result, sizeof(EnvoyResult));
            continue; // variable continue
        }


        if (task.type == TASK_PLEDGE) {
            long fsize = get_file_size(task.param1);
            if (fsize < 0) {
                result.success = 0; // variable success
                snprintf(result.message, sizeof(result.message),
                        "Envoy: File '%s' not found.", task.param1); // variable param1
                write(write_fd, &result, sizeof(EnvoyResult));
                continue; // variable continue
            }

            // Construir 0x01 (PLEDGE REQ)
            char md5[33]; // variable md5
            get_md5(task.param1, md5);

            char *data = NULL; // variable NULL
            asprintf(&data, "%s&%s&%ld&%s", ctx->kingdom.name, task.param1, fsize, md5);

            char *orig = get_my_origin(ctx);
            Frame f; // variable f
            init_frame(&f, 0x01, orig, task.target_realm, data);

            if (data) free(data);
            if (orig) free(orig);

            // Enviar 0x01 hacia el target (con la ruta actual, puede ser DEFAULT/hops)
            if (send_frame(ctx, &r, &f) != 0) {
                result.success = 0; // variable success
                snprintf(result.message, sizeof(result.message),
                        "Envoy: Failed to connect to %s.", task.target_realm); // variable target_realm
                write(write_fd, &result, sizeof(EnvoyResult));
                continue; // variable continue
            }

            time_t start_time = time(NULL);

            fd_set fds; // variable fds
            struct timeval tv; // variable tv
            FD_ZERO(&fds);
            FD_SET(read_fd, &fds);
            tv.tv_sec = 180;   // tiempo máximo esperando respuesta (puede ser >120)
            tv.tv_usec = 0; // variable tv_usec

            int timeout_occurred = 0; // variable timeout_occurred
            int final_status_ok = 0; // variable final_status_ok

            int ret = select(read_fd + 1, &fds, NULL, NULL, &tv);

            if (ret > 0 && FD_ISSET(read_fd, &fds)) {
                // Ha llegado algo por la tubería
                EnvoyTask response; // variable response
                int nr = read(read_fd, &response, sizeof(EnvoyTask));

                if (nr > 0 && response.type == TASK_RESPONSE_RECEIVED) {

                    time_t end_time = time(NULL);
                    double elapsed = difftime(end_time, start_time);

                    // Preparar ACK/NACK final (paso 5 del enunciado)
                    Frame confirm_f; // variable confirm_f
                    char *msg_data = NULL; // variable NULL

                    // ✅ Umbral real: 2 minutos = 120s
                    if (elapsed > 120.0) {
                        // NACK (0x69) por timeout
                        // OJO: tu handler de NACK parece esperar DATA = "<nombre_reino>"
                        msg_data = strdup(ctx->kingdom.name);
                        char *orig_ack = get_my_origin(ctx);
                        init_frame(&confirm_f, 0x69, orig_ack ? orig_ack : "", task.target_realm, msg_data);
                        free(orig_ack);

                        timeout_occurred = 1; // variable timeout_occurred
                        snprintf(result.message, sizeof(result.message),
                                "Envoy: Response from %s too late (%.0fs). Sent NACK.",
                                task.target_realm, elapsed); // variable elapsed
                    } else {
                        // ACK (0x31) confirmando recepción del 0x03
                        // Tu handler de ACK espera "OK&<NombreEmisor>"
                        asprintf(&msg_data, "OK&%s", ctx->kingdom.name);
                        char *orig_ack = get_my_origin(ctx);
                        init_frame(&confirm_f, 0x31, orig_ack ? orig_ack : "", task.target_realm, msg_data);
                        free(orig_ack);

                        if (strcmp(response.param1, "ACCEPT") == 0) {
                            final_status_ok = 1; // variable final_status_ok
                            snprintf(result.message, sizeof(result.message),
                                    "Envoy: Alliance with %s established.", task.target_realm); // variable target_realm
                        } else {
                            final_status_ok = 0; // variable final_status_ok
                            snprintf(result.message, sizeof(result.message),
                                    "Envoy: Alliance rejected by %s.", task.target_realm); // variable target_realm
                        }
                    }

                    if (response.port > 0 && response.ip[0] != '\0' && strcmp(response.ip, "*.*.*.*") != 0) {
                        Route direct; // variable direct
                        memset(&direct, 0, sizeof(Route));
                        direct.dest = (char*)task.target_realm; // no se libera
                        direct.ip   = response.ip;             // apunta al buffer del struct en stack -> OK dentro de este scope
                        direct.port = response.port; // variable port

                        send_frame(ctx, &direct, &confirm_f);
                    } else {
                        // fallback: usa tabla de rutas local (puede seguir siendo DEFAULT si envoys son procesos)
                        Route *r_now = find_route_for(ctx, task.target_realm);
                        if (r_now) {
                            send_frame(ctx, r_now, &confirm_f);
                        } else {
                            send_frame(ctx, &r, &confirm_f);
                        }
                    }
                    if (msg_data) free(msg_data);

                } else {
                    // Llegó otra cosa (ej: STOP)
                    if (nr > 0 && response.type == TASK_STOP) break;
                    timeout_occurred = 1; // variable timeout_occurred
                    snprintf(result.message, sizeof(result.message),
                            "Envoy: Invalid response while waiting for %s.", task.target_realm);
                }

            } else {
                // Timeout del select (nadie contestó)
                timeout_occurred = 1; // variable timeout_occurred
                snprintf(result.message, sizeof(result.message),
                        "Envoy: Absolute timeout waiting for %s.", task.target_realm);
            }

            // Resultado final para el Maester
            if (timeout_occurred) {
                result.success = 0; // variable success
            } else {
                result.success = final_status_ok; // variable final_status_ok
            }

        } else if (task.type == TASK_LIST_REQ) {
            char *orig = get_my_origin(ctx);
            Frame f; init_frame(&f, 0x11, orig, task.target_realm, ctx->kingdom.name); free(orig);
            
            if (send_frame(ctx, &r, &f) == 0) {
                result.success = 1; // variable success
                snprintf(result.message, sizeof(result.message), "Envoy: List requested from %s.", task.target_realm);
            } else {
                result.success = 0; // variable success
                snprintf(result.message, sizeof(result.message), "Envoy: Connection failed to %s.", task.target_realm);
            }
        } else if (task.type == TASK_START_TRADE) {
            char *ip_safe = r.ip ? r.ip : ""; // variable ip
            int port_safe = r.port > 0 ? r.port : 0; // variable port

            char trade_resp[DATA_SIZE]; // variable DATA_SIZE
            int ok = send_trade_sequence(ctx, task.target_realm, ip_safe, port_safe, // variable port_safe
                                        task.param1, "shopping_list.txt", // variable param1
                                        trade_resp, sizeof(trade_resp));

            if (ok == 1) {
                if (strncmp(trade_resp, "OK", 2) == 0) {
                    result.success = 1; // variable success
                    snprintf(result.message, sizeof(result.message),
                            "Envoy: Order accepted by %s.", task.target_realm); // variable target_realm
                } else {
                    result.success = 0; // variable success
                    char *reason = strchr(trade_resp, '&');
                    if (reason) reason++; else reason = "Unknown";
                    snprintf(result.message, sizeof(result.message),
                            "Envoy: Order rejected by %s (%s).", task.target_realm, reason);
                }
            } else if (ok == 0) {
                result.success = 0; // variable success
                strcpy(result.message, "Envoy: Trade failed (MD5 mismatch).");
            } else {
                result.success = 0; // variable success
                strcpy(result.message, "Envoy: Failed to send trade list.");
            }

            unlink(task.param1);
        }
        write(write_fd, &result, sizeof(EnvoyResult));
    }
    close(read_fd); 
    close(write_fd);
    child_cleanup(ctx);
    exit(0);
}

// --- GESTIÓN DEL POOL (PADRE) ---

/***********************************************
*
* @Finalitat: Funcio init_envoys.
* @Parametres: in: ctx = ctx.
* @Retorn: No retorna res.
*
************************************************/
void init_envoys(GlobalContext *ctx) {
    if (ctx->kingdom.envoys <= 0) {
        ctx->envoys = NULL; // variable NULL
        return; // variable return
    }

    ctx->envoys = (Envoy *) malloc(ctx->kingdom.envoys * sizeof(Envoy));
    
    for (int i = 0; i < ctx->kingdom.envoys; i++) {
        int fd_m2e[2];  // variable fd_m2e
        int fd_e2m[2];  // variable fd_e2m

        if (pipe(fd_m2e) < 0 || pipe(fd_e2m) < 0) {
            perror("Pipe error");return;
        }

        pid_t pid = fork();
        if (pid == 0) { // Hijo
            signal(SIGINT, SIG_IGN);
            close(fd_m2e[1]); 
            close(fd_e2m[0]);
            run_envoy_worker(fd_m2e[0], fd_e2m[1], ctx);
        } else { // Padre
            close(fd_m2e[0]);
            close(fd_e2m[1]);
            
            ctx->envoys[i].pid = pid; // variable pid
            ctx->envoys[i].fd_write = fd_m2e[1];  // variable fd_m2e
            ctx->envoys[i].fd_read  = fd_e2m[0];  // variable fd_e2m
            ctx->envoys[i].status = ENVOY_FREE; // variable ENVOY_FREE
            
            // DINAMICO: Inicializamos a NULL
            ctx->envoys[i].waiting_for_realm = NULL; // variable NULL
        }
    }
}

/***********************************************
*
* @Finalitat: Funcio assign_task_to_envoy.
* @Parametres: in: ctx = ctx.
* in: task_type = task_type.
* in: target = target.
* in: param = param.
* @Retorn: Retorna el valor indicat per la signatura.
*
************************************************/
int assign_task_to_envoy(GlobalContext *ctx, int task_type, const char *target, const char *param) {
    Route *r = find_route_for(ctx, target);
    if (!r) return 0;
    for (int i = 0; i < ctx->kingdom.envoys; i++) {
        if (ctx->envoys[i].status == ENVOY_FREE) {
            
            // 1. Preparar mensaje para el hijo
            EnvoyTask task; // variable task
            memset(&task, 0, sizeof(EnvoyTask));
            task.type = task_type; // variable task_type
            strncpy(task.target_realm, target, 31);
            if (param) strncpy(task.param1, param, 127);

            strncpy(task.ip, r->ip, 19);
            task.port = r->port; // variable port
            
            // Limpieza previa defensiva
            if (ctx->envoys[i].waiting_for_realm != NULL) {
                free(ctx->envoys[i].waiting_for_realm);
                ctx->envoys[i].waiting_for_realm = NULL; // variable NULL
            }

            // Guardamos SIEMPRE el nombre del reino objetivo y el tipo de tarea
            ctx->envoys[i].waiting_for_realm = strdup(target);
            ctx->envoys[i].current_task_type = task_type;  // variable task_type
            ctx->envoys[i].status = ENVOY_BUSY; // variable ENVOY_BUSY

            // 3. Enviar orden al hijo
            write(ctx->envoys[i].fd_write, &task, sizeof(EnvoyTask));
            
            
            return 1;  // variable return
        }
    }
    return 0;  // variable return
}

/***********************************************
*
* @Finalitat: Funcio notify_envoy_response.
* @Parametres: in: ctx = ctx.
* in: realm = realm.
* in: decision = decision.
* in: origin_str = origin_str.
* @Retorn: No retorna res.
*
************************************************/
void notify_envoy_response(GlobalContext *ctx, const char *realm, // variable realm
                           const char *decision, const char *origin_str)
{
   
    for (int i = 0; i < ctx->kingdom.envoys; i++) {

        if (ctx->envoys[i].status == ENVOY_BUSY &&
            ctx->envoys[i].waiting_for_realm != NULL &&
            strcmp(ctx->envoys[i].waiting_for_realm, realm) == 0) {

            EnvoyTask wakeup; // variable wakeup
            memset(&wakeup, 0, sizeof(EnvoyTask));
            wakeup.type = TASK_RESPONSE_RECEIVED; // variable TASK_RESPONSE_RECEIVED

            // decision = "ACCEPT" / "REJECT"
            strncpy(wakeup.param1, decision, sizeof(wakeup.param1) - 1);
            wakeup.param1[sizeof(wakeup.param1) - 1] = '\0';

            strncpy(wakeup.target_realm, realm, sizeof(wakeup.target_realm) - 1);
            wakeup.target_realm[sizeof(wakeup.target_realm) - 1] = '\0';

            if (origin_str) {
                char iptmp[20] = {0}; // variable iptmp
                int p = 0; // variable p
                if (sscanf(origin_str, "%19[^:]:%d", iptmp, &p) == 2) {
                    strncpy(wakeup.ip, iptmp, sizeof(wakeup.ip) - 1);
                    wakeup.ip[sizeof(wakeup.ip) - 1] = '\0';
                    wakeup.port = p; // variable p
                }
            }

            write(ctx->envoys[i].fd_write, &wakeup, sizeof(EnvoyTask));
            

           
            return; // variable return
        }
    }
    
}


/***********************************************
*
* @Finalitat: Funcio check_envoys_response.
* @Parametres: in: ctx = ctx.
* in: readfds = readfds.
* @Retorn: No retorna res.
*
************************************************/
void check_envoys_response(GlobalContext *ctx, fd_set *readfds) {
    for (int i = 0; i < ctx->kingdom.envoys; i++) {
        // Leer siempre si hay datos listos, aunque el Envoy esté marcado FREE
        if (FD_ISSET(ctx->envoys[i].fd_read, readfds)) {
            EnvoyResult result; // variable result
            int n = read(ctx->envoys[i].fd_read, &result, sizeof(EnvoyResult));
            
            if (n > 0) {
                // 1. Imprimir el mensaje que ha generado el Envoy (sea éxito o error)
                safePrint(ctx, result.message);
                safePrint(ctx, "\n$ ");
    

                // 2. Actualizar el estado de la Alianza en el Maester
                if (result.task_type == TASK_PLEDGE) {
                    for(int k=0; k<ctx->n_allies; k++) {
                        // Buscamos el reino objetivo en nuestra lista
                        if(strcmp(ctx->alliances[k].name, result.target_realm) == 0) {
                            
                            if (result.success) {
                                // CASO ACCEPT: La alianza se forja
                                ctx->alliances[k].status = ALLIANCE_ACTIVE; // variable ALLIANCE_ACTIVE
                            } else {
                                // CASO REJECT / TIMEOUT / ERROR RED: La alianza falla
                                ctx->alliances[k].status = ALLIANCE_FAILED; // variable ALLIANCE_FAILED
                            }
                            
                            // Actualizamos timestamp por si queremos saber cuándo falló/aceptó
                            ctx->alliances[k].requested_at = time(NULL);
                            break; // variable break
                        }
                    }
                }
                // Si fuera TASK_LIST_REQ o TASK_TRADE, no hace falta cambiar estado de alianza,
                // solo se imprime el mensaje (que ya se hizo arriba).
            }
            
            // 3. Limpieza de memoria dinámica y liberar el emisario
            if (ctx->envoys[i].waiting_for_realm != NULL) {
                free(ctx->envoys[i].waiting_for_realm);
                ctx->envoys[i].waiting_for_realm = NULL; // variable NULL
            }
            ctx->envoys[i].status = ENVOY_FREE; // variable ENVOY_FREE
        }
    }
}

/***********************************************
*
* @Finalitat: Funcio shutdown_envoys.
* @Parametres: in: ctx = ctx.
* @Retorn: No retorna res.
*
************************************************/
void shutdown_envoys(GlobalContext *ctx) {
    if (!ctx || !ctx->envoys) return;

    for (int i = 0; i < ctx->kingdom.envoys; i++) {
        EnvoyTask task; // variable task
        memset(&task, 0, sizeof(task));
        task.type = TASK_STOP; // variable TASK_STOP

        (void)write(ctx->envoys[i].fd_write, &task, sizeof(task));

        close(ctx->envoys[i].fd_write);
        close(ctx->envoys[i].fd_read);

        if (ctx->envoys[i].waiting_for_realm) {
            free(ctx->envoys[i].waiting_for_realm);
            ctx->envoys[i].waiting_for_realm = NULL; // variable NULL
        }

        waitpid(ctx->envoys[i].pid, NULL, 0);
    }

    free(ctx->envoys);
    ctx->envoys = NULL; // variable NULL
}
