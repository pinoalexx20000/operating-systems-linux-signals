#ifndef ENVOY_CONTROLLER_H
#define ENVOY_CONTROLLER_H

#include "structs.h"
#include "network_controller.h"
#include "auxiliars.h"

void init_envoys(GlobalContext *ctx);
int assign_task_to_envoy(GlobalContext *ctx, int task_type, const char *target, const char *param);
void check_envoys_response(GlobalContext *ctx, fd_set *readfds);
void shutdown_envoys(GlobalContext *ctx);

// NUEVO: Función para despertar al Envoy cuando llega la respuesta por red
void notify_envoy_response(GlobalContext *ctx, const char *realm, const char *decision, const char *origin_str);

#endif