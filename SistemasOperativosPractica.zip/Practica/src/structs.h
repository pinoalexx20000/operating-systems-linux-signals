/***********************************************
*
* @Proposit: Conté les estructures de dades principals del programa
*             (Kingdom, Route, Product, TradeList) i funcions auxiliars
*             per mostrar informació relacionada amb aquestes estructures.
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#ifndef STRUCTS_H
#define STRUCTS_H

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "auxiliars.h"
#include "semaphore_v2.h"


//Comandes disponibles per al mode trade.
#define TRADE_SEND          "send"                                                                      //Envia la llista de comerç.
#define TRADE_ADD           "add"                                                                       //Afegeix un producte a la llista. 
#define TRADE_REMOVE        "remove"                                                                    //Elimina un producte de la llista.
#define TRADE_CANCEL         "cancel"                                                                    //Cancela el mode de comerç. 
#define MISS                "Missing arguments.Please review the syntax.\n"                             //Missatge d'error per falta d'arguments.
#define MISS_START_TRADE   "Missing arguments, can’t start a trade. Please review the syntax.\n"        //Missatge d'error per falta d'arguments.
#define MISS_TRADE          "Missing arguments, can’t trade. Please review the syntax.\n"               //Missatge d'error per falta d'arguments.

#define ERR_SLCT "El select() ha dado error\n"

// ============================
// CONSTANTES FASE 4 (ENVOYS)
// ============================

// Tipos de Tarea (Maester -> Envoy)
#define TASK_PLEDGE       1
#define TASK_LIST_REQ     2
#define TASK_START_TRADE  3
#define TASK_STOP         99 // Para matar al proceso hijo limpiamente

#define TASK_RESPONSE_RECEIVED 50 

// Estados del Envoy
#define ENVOY_FREE        0
#define ENVOY_BUSY        1


/***********************************************
*
* @Finalitat: Representa una ruta de comunicació entre regnes,
*              incloent el destí, la seva IP i el port de connexió.
*
************************************************/

typedef struct {
    char *dest;     //Nom del regne de destí.
    char *ip;       //Adreça IP del regne de destí.
    int port;       //Port utilitzat per la comunicació.
} Route;

/***********************************************
*
* @Finalitat: Conté tota la informació d’un regne,
*              com el nom, camí de fitxers, enviats, 
*              adreça IP, port i les seves rutes disponibles.
*
************************************************/

typedef struct {
    char *name;     //Nom del regne.    
    char *path;     //Ruta d’emmagatzematge associada al regne.
    int envoys;     //Nombre d’enviats disponibles.
    char *ip;       //Adreça IP del regne.
    int port;       //Port de comunicació del regne.
    Route *routes;  //Llista de rutes de comunicació amb altres regnes.
    int n_routes;   //Nombre total de rutes.
} Kingdom;

/***********************************************
*
* @Finalitat: Representa un producte dins del sistema de comerç,
*              incloent el seu nom, quantitat i pes.
*
************************************************/

typedef struct {
    char name[100]; //Nom del producte.
    int amount;     //Quantitat disponible del producte.
    float weight;   //Pes del producte.
} Product;

/***********************************************
*
* @Finalitat: Defineix un element d’intercanvi dins de la llista de comerç,
*              indicant quin producte s’intercanvia i en quina quantitat.
*
************************************************/



typedef struct {
    Product item;   //Producte associat a l’intercanvi.
    int amount;     //Quantitat del producte per intercanviar.
} TradeList;

typedef enum {
    UNKNOWN,
    ALLIANCE_NONE,    /* sin interacción/estado por defecto */
    ALLIANCE_PENDING,     /* se ha enviado/recibido solicitud y está pendiente */
    ALLIANCE_ACTIVE,      /* alianza establecida */
    ALLIANCE_FAILED     /* solicitud rechazada */
} AllianceStatus;

typedef struct {
    char *name;     /* nombre del reino (null-terminated) */
    AllianceStatus status;    /* estado de la alianza con ese reino */
    time_t requested_at;
} AllianceRecord;

typedef struct {
    int type;               // TASK_PLEDGE, TASK_LIST_REQ...
    char target_realm[32];  // Nombre del reino destino
    char param1[128];       // Ej: nombre fichero imagen, o vacio
    char ip[20];
    int port;
} EnvoyTask;

// Mensaje que devuelve el Envoy al Maester
typedef struct {
    int success;            // 1 = Éxito, 0 = Fallo
    char message[256];      // Texto para imprimir por pantalla al usuario
    char target_realm[32];  // Reino implicado
    int task_type;          // Tarea completada
   
} EnvoyResult;

// Estructura de gestión de un Emisario (Lado Maester)
// Estructura de gestión de un Emisario (Lado Maester)
typedef struct {
    pid_t pid;          // ID del proceso hijo
    
    // CAMBIO IMPORTANTE: Separamos en dos variables para evitar errores de array
    int fd_write;       // El Maester usa este para ENVIAR tareas al hijo
    int fd_read;        // El Maester usa este para RECIBIR respuestas del hijo
    
    int status;         // ENVOY_FREE o ENVOY_BUSY

    char *waiting_for_realm; // Reino del que está esperando respuesta (si aplica)
    int current_task_type;
} Envoy;


typedef struct {
    Kingdom kingdom;
    Product *products;
    int n_products;
    
    char *main_line;
    char *trade_line;
    
    TradeList *trade_list;
    int trade_count;
    
    AllianceRecord *alliances;
    int n_allies;
    
    semaphore print_sem;
    int print_initialized;

    semaphore ctx_sem;
    int ctx_sem_initialized;

    semaphore stock_sem;
    int stock_sem_initialized;
    
    int pipeServer[2];

    Envoy *envoys; 

} GlobalContext;

/***********************************************
*
* @Finalitat: Mostra per pantalla el nom del regne actual conegut.
* @Parametres:
*   - kingdom: estructura que conté la informació del regne actual.
* @Retorn: void.
*
************************************************/

void list_realms(Kingdom kingdom);

/***********************************************
*
* @Finalitat: Mostra una taula amb els productes locals del regne.
* @Parametres:
*   - products: llista de productes.
*   - n_products: nombre total de productes.
* @Retorn: void.
*
************************************************/

void list_local_products(Product *products, int n_products);

/***********************************************
*
* @Finalitat: Mostra una llista simple de productes disponibles per comerciar.
* @Parametres:
*   - products: llista de productes.
*   - n_products: nombre total de productes.
* @Retorn: void.
*
************************************************/

void list_available_products(Product *products, int n_products);

#endif
