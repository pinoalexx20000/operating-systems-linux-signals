#ifndef PROTOCOL_H
#define PROTOCOL_H

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <signal.h>

// ============================
// Constantes del protocolo
// ============================

// Tamaño fijo del frame (320 bytes)
#define FRAME_SIZE 320

// Tipos de mensaje usados en Fase 2
#define TYPE_PLEDGE_REQ        0x01  // Petición de alianza
#define TYPE_SIGIL_ENV         0x02  // Envío de Sello Real
#define TYPE_RESPONSE          0x03  // Respuesta (ACCEPT / REJECT)
#define TYPE_ACK               0x31  // Confirmación de recepción
#define TYPE_NACK              0x69  // Error o timeout

#define TYPE_LIST_PRODUCTS_REQ 0x11  // Solicitud de lista de productos  
#define TYPE_LIST_PRODUCTS_RESP 0x12   
#define TYPE_DISCONNECT        0x27  // Aviso de desconexión

// Tipos de mensaje pensando en la fase 3
#define TYPE_SHOPPING_HEADER   0x14  // petición de comanda 
#define TYPE_SHOPPING_RESPONSE 0x16  // respuesta a la comanda

// Límites de campos (simplificados)
#define ORIGIN_SIZE       20
#define DEST_SIZE         20
#define DATA_SIZE         275   // 320 - (1+20+20+2+2)

#define OFF_TYPE      0
#define OFF_ORIGIN    1
#define OFF_DEST      21
#define OFF_LEN       41
#define OFF_DATA      43
#define OFF_CHECK     318

// ============================
// Estructura del Frame
// ============================

#pragma pack(push, 1)
typedef struct {
    uint8_t type;                       // Tipo de mensaje
    char origin[ORIGIN_SIZE];           // IP:Port del emisor
    char destination[DEST_SIZE];        // Nombre del reino destino
    uint16_t data_length;               // Longitud real de data
    char data[DATA_SIZE];               // Datos en texto plano (header)
    uint16_t checksum;                  // Suma de control simple
} Frame;
#pragma pack(pop)

// ============================
// Funciones del protocolo
// ============================

/**
 * @brief Inicializa un frame con los datos básicos.
 */
void init_frame(Frame* f, uint8_t type, const char* origin, const char* dest, const char* data);

/**
 * @brief Calcula el checksum (suma de bytes mod 65536).
 */
uint16_t calculate_checksum(Frame* f);

/**
 * @brief Serializa un frame a un buffer de 320 bytes (para enviar por socket).
 */
void serialize_frame(Frame* f, unsigned char buffer[FRAME_SIZE]);

/**
 * @brief Deserializa un buffer de 320 bytes recibido desde el socket.
 */
int deserialize_frame(unsigned char buffer[FRAME_SIZE], Frame* f);

/**
 * @brief Valida si el checksum del frame es correcto.
 * @return 1 si es correcto, 0 si no.
 */

#endif
