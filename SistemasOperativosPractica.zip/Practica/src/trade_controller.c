//************
// Mòdul: trade_controller.c
//************

#define _GNU_SOURCE
#include "trade_controller.h"
#include <unistd.h>

// --- HELPER PARA PARSEAR EL CATALOGO EXTERNO ---

/**
 * @brief Busca un producto en el fichero de catálogo de un reino.
 * Formato linea: "ID. Nombre (Qty units)"
 * @return Cantidad disponible, o -1 si no existe.
 */
long get_remote_product_stock(GlobalContext *ctx, const char *realm, const char *product_name) {
    char *filename;
    asprintf(&filename, ".%s/catalog_%s.txt", ctx->kingdom.path, realm);
    
    int fd = open(filename, O_RDONLY);
    free(filename);
    
    if (fd < 0) return -2; // -2 = Catálogo no existe (hacer LIST primero)

    char *line;
    long available = -1;
    
    // Leemos línea a línea usando read_until (System Call)
    while ((line = read_until(fd, '\n')) != NULL) {
        if (strlen(line) < 5) { free(line); continue; } 
        
        // Formato esperado: "1. Iron Dagger (35 units)"
        // Estrategia de parseo manual robusta:
        
        // 1. Saltar ID y punto inicial
        char *p = line;
        while (*p && *p != '.') p++; 
        if (!*p) { free(line); continue; }
        p++; // Saltar punto
        while (*p == ' ') p++; // Saltar espacios
        
        // 2. p apunta al inicio del nombre.
        // Buscamos el último paréntesis abierto '(' que marca la cantidad
        char *last_paren = strrchr(p, '(');
        if (!last_paren) { free(line); continue; }
        
        // 3. Aislar nombre
        // El nombre termina antes del paréntesis (y quitando espacios finales)
        char *end_name = last_paren - 1;
        while (end_name > p && *end_name == ' ') end_name--;
        *(end_name + 1) = '\0';
        
        char *current_name = p;
        
        // 4. Aislar cantidad (después del paréntesis)
        char *qty_str = last_paren + 1;
        long qty = strtol(qty_str, NULL, 10);

        // 5. Comparar nombres (Case insensitive)
        char *n1 = strdup(current_name);
        char *n2 = strdup(product_name);
        to_lowercase(n1);
        to_lowercase(n2);
        
        if (strcmp(n1, n2) == 0) {
            available = qty;
            free(n1); free(n2);
            free(line);
            break; // Encontrado
        }
        
        free(n1); free(n2);
        free(line);
    }
    
    close(fd);
    return available;
}

// ---------------------------------------------

static void remove_catalog(GlobalContext *ctx, const char *realm) {
    char *filename = NULL;
    if (!ctx || !realm) return;
    if (asprintf(&filename, ".%s/catalog_%s.txt", ctx->kingdom.path, realm) < 0 || !filename) {
        return;
    }
    unlink(filename);
    free(filename);
}

void print_current_list(GlobalContext *ctx) {
    if (ctx->trade_count == 0) {
        printStatic("\n--- Empty List ---\n");
        return;
    }
    printStatic("\n--- Current List ---\n");
    for (int i = 0; i < ctx->trade_count; i++) {
        char *buf;
        asprintf(&buf, "%d. %s (%d)\n", i + 1, ctx->trade_list[i].item.name, ctx->trade_list[i].amount);
        safePrint(ctx, buf);
        free(buf);
    }
    printStatic("--------------------\n");
}

int trade_process_command(GlobalContext *ctx, char *realm) {
    if (!ctx || !ctx->trade_line) return 0;

    char *line_copy = strdup(ctx->trade_line);
    if (!line_copy) return 0;
    line_copy[strcspn(line_copy, "\n")] = 0; 

    char *cmd = strtok(line_copy, " ");
    if(!cmd){
        safePrint(ctx, MISS);
        free(line_copy);
        return 0;
    }
    to_lowercase(cmd);

    // --- ADD ---
    if (strcmp(cmd, TRADE_ADD) == 0) {
        char *args = strtok(NULL, ""); 
        if (!args || strlen(args) == 0) {
            safePrint(ctx, MISS_TRADE);
            free(line_copy); return 0;
        }
        
        // Parsing "Nombre Cantidad"
        while (*args == ' ') args++;
        char *p = args + strlen(args) - 1;
        while (p > args && *p != ' ') p--;
        if (p == args) {
            safePrint(ctx, "Missing quantity after product name.\n");
            free(line_copy); return 0;
        }
        p++;
        char *endptr;
        long quantity = strtol(p, &endptr, 10);
        if (*endptr != '\0' || quantity <= 0) {
            safePrint(ctx, "Invalid quantity.\n");
            free(line_copy); return 0;
        }
        *(p - 1) = '\0';
        while (strlen(args) > 0 && args[strlen(args) - 1] == ' ') args[strlen(args) - 1] = '\0';

        // VERIFICACIÓN CON EL STOCK REMOTO (CATÁLOGO)
        long stock_remote = get_remote_product_stock(ctx,realm, args);
        
        if (stock_remote == -2) {
            safePrint(ctx, "Catalog not found. Please run 'LIST PRODUCTS' first.\n");
            // Aquí podríamos forzar salir del modo trade, pero el enunciado dice "no permitir añadir".
        } else if (stock_remote == -1) {
            char *buf; asprintf(&buf, "Product '%s' not found in %s's catalog.\n", args, realm);
            safePrint(ctx, buf); free(buf);
        } else if (quantity > stock_remote) {
            char *buf; asprintf(&buf, "Not enough stock in %s. Available: %ld\n", realm, stock_remote);
            safePrint(ctx, buf); free(buf);
        } else {
            // Añadir a lista local
            int in_list = 0;
            if (ctx->trade_list) {
                for (int i = 0; i < ctx->trade_count; i++) {
                    // Check local duplicate
                    char *n1 = strdup(ctx->trade_list[i].item.name);
                    char *n2 = strdup(args);
                    to_lowercase(n1); to_lowercase(n2);
                    if (strcmp(n1, n2) == 0) {
                        ctx->trade_list[i].amount += quantity;
                        in_list = 1; 
                    }
                    free(n1); free(n2);
                    if(in_list) break;
                }
            }
            if (!in_list) {
                TradeList *tmp = realloc(ctx->trade_list, (ctx->trade_count + 1) * sizeof(TradeList));
                if (tmp) {
                    ctx->trade_list = tmp;
                    strcpy(ctx->trade_list[ctx->trade_count].item.name, args); // Copiamos nombre tal cual metió user
                    ctx->trade_list[ctx->trade_count].amount = quantity;
                    ctx->trade_count++;
                }
            }
            print_current_list(ctx);
        }

    // --- REMOVE ---
    } else if (strcmp(cmd, TRADE_REMOVE) == 0) {
        char *arg = strtok(NULL, " ");
        if (!arg) {
            safePrint(ctx, "Missing product ID.\n");
        } else {
            long id = atol(arg);
            if (id <= 0 || id > ctx->trade_count) {
                safePrint(ctx, "Invalid ID.\n");
            } else {
                int idx = id - 1;
                for (int i = idx; i < ctx->trade_count - 1; i++) {
                    ctx->trade_list[i] = ctx->trade_list[i + 1];
                }
                ctx->trade_count--;
                if (ctx->trade_count == 0) {
                    free(ctx->trade_list); ctx->trade_list = NULL;
                } else {
                    TradeList *tmp = realloc(ctx->trade_list, ctx->trade_count * sizeof(TradeList));
                    if(tmp) ctx->trade_list = tmp;
                }
                safePrint(ctx, "Item removed.\n");
                print_current_list(ctx);
            }
        }

    // --- CANCEL ---
    } else if (strcmp(cmd, TRADE_CANCEL) == 0) {
        if (ctx->trade_list) free(ctx->trade_list);
        ctx->trade_list = NULL;
        ctx->trade_count = 0;
        safePrint(ctx, "Trade cancelled.\n");
        remove_catalog(ctx, realm);
        free(line_copy);
        return 1; 

    // --- SEND ---
    } else if (strcmp(cmd, TRADE_SEND) == 0) {
        if (ctx->trade_count == 0) {
            safePrint(ctx, "List is empty.\n");
        } else {
            char temp_file[] = "temp_shopping_list.txt";
            if (saveTradeListToTempFile(ctx->trade_list, ctx->trade_count, temp_file) == 0) {
                if (assign_task_to_envoy(ctx, TASK_START_TRADE, realm, temp_file)) {
                    char *buf;
                    asprintf(&buf, "Envoy assigned to negotiate with %s.\n", realm);
                    safePrint(ctx, buf);
                    free(buf);
                    free(ctx->trade_list);
                    ctx->trade_list = NULL;
                    ctx->trade_count = 0;
                    remove_catalog(ctx, realm);
                    free(line_copy);
                    return 1; 
                } else {
                    safePrint(ctx, "All envoys busy.\n");
                    unlink(temp_file);
                }
            }
        }

    } else {
        printStatic("Unknown command\n");
    }

    free(line_copy);
    return 0;
    
}

void menu_trade(GlobalContext *ctx, char *realm) {
    // 1. Comprobamos si tenemos el catálogo antes de entrar
    char *cat_file;
    asprintf(&cat_file, ".%s/catalog_%s.txt", ctx->kingdom.path, realm);

    if (access(cat_file, F_OK) != 0) {
        safePrint(ctx, "No products available. Use LIST PRODUCTS first.\n");
        free(cat_file);
        return; // No entramos en modo trade
    }
    free(cat_file);

    // Entramos en modo trade
    if (ctx->trade_list) { free(ctx->trade_list); ctx->trade_list = NULL; }
    ctx->trade_count = 0;                        
    
    int finish = 0;                   
    char *buf;
    asprintf(&buf, "Entering trade mode with %s.\n", realm);
    safePrint(ctx, buf);
    free(buf);

    while (!finish) {
        safePrint(ctx, "(trade)> ");
        ctx->trade_line = read_until(STDIN_FILENO, '\n');

        if (ctx->trade_line) {
            finish = trade_process_command(ctx, realm);
            free(ctx->trade_line);
            ctx->trade_line = NULL;
        } else {
            finish = 1; 
        }
    }
}
