#include "safe_print.h"

/**
 * @brief Inicializa el semáforo binario para sincronización de prints
 */
int initPrint(GlobalContext *ctx) {
    if (!ctx) return -1;
    
    if (ctx->print_initialized) {
        return 0; 
    }

    if (SEM_constructor(&ctx->print_sem) < 0) {
        return -1;
    }

    if (SEM_init(&ctx->print_sem, 1) < 0) {
        return -1;
    }

    ctx->print_initialized = 1;
    return 0;
}

/**
 * @brief Destruye el semáforo de impresión
 */
int destroyPrint(GlobalContext *ctx) {
    if (!ctx || !ctx->print_initialized) {
        return 0;
    }

    if (SEM_destructor(&ctx->print_sem) < 0) {
        return -1;
    }

    ctx->print_initialized = 0;
    return 0;
}

/**
 * @brief Imprime un mensaje de forma sincronizada
 */
void safePrint(GlobalContext *ctx, const char *msg) {
    if (!ctx || !msg || !ctx->print_initialized) {
        return;
    }

    SEM_wait(&ctx->print_sem);
    write(STDOUT_FILENO, msg, strlen(msg));
    SEM_signal(&ctx->print_sem);
}