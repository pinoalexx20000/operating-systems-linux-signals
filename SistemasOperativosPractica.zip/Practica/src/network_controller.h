#ifndef _NETWORK_CONTROLLER_H_
#define _NETWORK_CONTROLLER_H_

#define _GNU_SOURCE
#include "auxiliars.h" // Necesario para get_md5 y get_file_size
#include <sys/stat.h> 
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "structs.h"
#include "protocol.h"
#include <stdlib.h>
#include <stdio.h> // Únicamente para asprintf
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <pthread.h>
#include "safe_print.h"
#include "persistence.h"
#include "envoy_controller.h"

/* Códigos de error */
#define ERR_CODE_SOCKET -1
#define ERR_SOCKET "Error: socket creation failed\n"
#define ERR_BIND "Error: bind failed\n"
#define ERR_LISTEN "Error: listen failed\n"
#define ERR_ACCEPT "Error: accept failed\n"
#define ERR_CONV_IP "Error: IP conversion failed\n"

#define MAX_CONN 5
#define PRODUCT_NAME_SIZE 64
#define MAX_PRODUCTS 100
#define MAX_ROUTES 32
#define MAX_ALLIES 32
#define PLEDGE_TIMEOUT_SECS 120

typedef struct {
    int fd_client;
    GlobalContext* ctx;
} ClientHandlerArgs; 

char* get_my_origin(GlobalContext *ctx);
/* Funciones de alianzas */
void mark_allied(GlobalContext *ctx, const char *realm);
void mark_failed(GlobalContext *ctx, const char *realm);
int is_allied(GlobalContext *ctx, const char *realm);
int is_waiting_pledge(GlobalContext *ctx);
const char* get_pending_realm(GlobalContext *ctx);
int is_failed_realm(GlobalContext *ctx, const char *realm);

/* Funciones de ruteig */
Route* find_route_for(GlobalContext *ctx, const char *dest);

/* Funciones de sockets */
int open_listen_socket(const char *ip, int port);
void* start_server(void* args);
void* handle_incoming_message(void* args);
int send_frame(GlobalContext *ctx, Route* route, Frame* f);
void send_disconnect(GlobalContext* ctx);

int send_file_sequence(GlobalContext *ctx, Route *route, const char *filepath, const char *filename_virtual, int type_header, int type_data);
int send_trade_sequence(GlobalContext *ctx, const char* dest_name, const char* dest_ip, int dest_port, const char *filepath, const char *filename_virtual, char *resp_out, size_t resp_out_sz);

// Asegúrate de que receive_file_sequence también esté si la usas fuera
void receive_file_sequence(GlobalContext *ctx, int fd, Frame *header, const char *outfile);

#endif