/***********************************************
*
* @Proposit: Defineix les funcions auxiliars i declaracions globals utilitzades en tot el projecte.
* @Autor/s: Alex Ortiz i Bruno Xampeny
* @Data creacio: 06/10/2025
* @Data ultima modificacio: 26/10/2025
*
************************************************/

#ifndef AUXILIARS_H
#define AUXILIARS_H

#define _GNU_SOURCE

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/stat.h>

long get_file_size(const char *filename);

// Obtiene el MD5 usando el comando del sistema 'md5sum'
void get_md5(const char *filename, char *output_buffer);

/***********************************************
*
* @Finalitat: Escriu una cadena a un file descriptor.
* @Parametres:
*   - fd: descriptor de destí.
*   - x: cadena a escriure.
* @Retorn: void.
*
************************************************/

#define printStaticFd(fd, x) write(fd, x, strlen(x))

/***********************************************
*
* @Finalitat: Mostra un missatge per la sortida estàndard.
* @Parametres:
*   - x: cadena de text a imprimir.
* @Retorn: void.
*
************************************************/

#define printStatic(x) printStaticFd(STDOUT_FILENO, x)

/***********************************************
*
* @Finalitat: Allibera el punter.
* @Parametres:
*   - ptr: punter a alliberar.
* @Retorn: void.
*
************************************************/

#define GLOBAL_FREE(ptr) \
    if (ptr != NULL) { \
        free(ptr); \
        ptr = NULL; \
    }

/***********************************************
*
* @Finalitat: Llegeix caràcters d’un file descriptor fins trobar un delimitador o final de fitxer.
* @Parametres: 
*   - fd: file descriptor d’on es llegeix.
*   - delimiter: caràcter que marca el final de la lectura.
* @Retorn: Cadena dinàmica amb el contingut llegit o NULL en cas d’error.
*
************************************************/

char* read_until(int fd, char delimiter);

/***********************************************
*
* @Finalitat: Converteix una cadena a minúscules.
* @Parametres:
*   - str: cadena d’entrada que serà modificada in-place.
* @Retorn: void.
*
************************************************/

void to_lowercase(char *s);

/***********************************************
*
* @Finalitat: Crea una nova cadena dinàmica amb format, similar a printf.
* @Parametres:
*   - format: cadena de format.
*   - ...: arguments variables per formatar.
* @Retorn: Nova cadena dinàmica creada amb el contingut formatat.
*
************************************************/

char* GLOBAL_dynamicFormat(const char* format, ...);

/***********************************************
*
* @Finalitat: Mostra per pantalla una cadena amb format dinàmicament.
* @Parametres:
*   - format: cadena de format.
*   - ...: arguments variables.
* @Retorn: void.
*
************************************************/

void GLOBAL_dynamicPrint(const char* message, ...);

#endif
