//************
// Mòdul: protocol.c
//************

#include "protocol.h"

// Offsets del protocolo (según PDF)
#define OFF_TYPE      0
#define OFF_ORIGIN    1
#define OFF_DEST      21
#define OFF_LEN       41
#define OFF_DATA      43
#define OFF_CHECK     318

/**
 * @brief Suma bytes para checksum
 */
uint16_t calculate_checksum_internal(const unsigned char buffer[FRAME_SIZE]) {
    uint32_t sum = 0;
    // Sumamos todos los bytes EXCEPTO los últimos 2 (que son el propio checksum)
    for (int i = 0; i < OFF_CHECK; i++) {
        sum += buffer[i];
    }
    return (uint16_t)(sum % 65536);
}

void init_frame(Frame* f, uint8_t type, const char* origin, const char* dest, const char* data) {
    memset(f, 0, sizeof(Frame));
    f->type = type;

    // Usamos strncpy para evitar desbordamientos de buffer
    if (origin) strncpy(f->origin, origin, ORIGIN_SIZE - 1);
    if (dest) strncpy(f->destination, dest, DEST_SIZE - 1);

    if (data) {
        // Copiamos datos. Si es texto, strncpy va bien. 
        // Si fuera imagen binaria pura, se debería usar memcpy desde fuera.
        // Para headers (LIST, PLEDGE REQ), es texto, así que esto es seguro.
        strncpy(f->data, data, DATA_SIZE); 
        
        // Calculamos longitud.
        f->data_length = strnlen(data, DATA_SIZE);
    } else {
        f->data_length = 0;
    }
    f->checksum = 0;
}

void serialize_frame(Frame* f, unsigned char buffer[FRAME_SIZE]) {
    // 1. Limpiar buffer con ceros (Padding)
    memset(buffer, 0, FRAME_SIZE);

    // 2. Type
    buffer[OFF_TYPE] = f->type;

    // 3. Origin y Destination
    memcpy(buffer + OFF_ORIGIN, f->origin, ORIGIN_SIZE);
    memcpy(buffer + OFF_DEST, f->destination, DEST_SIZE);

    // 4. Data Length (Network Byte Order)
    uint16_t len_net = htons(f->data_length);
    memcpy(buffer + OFF_LEN, &len_net, sizeof(uint16_t));

    // 5. Data
    memcpy(buffer + OFF_DATA, f->data, DATA_SIZE);

    // 6. Checksum
    uint16_t checksum = calculate_checksum_internal(buffer);
    f->checksum = checksum; 

    uint16_t check_net = htons(checksum);
    memcpy(buffer + OFF_CHECK, &check_net, sizeof(uint16_t));
}

int validate_checksum(unsigned char buffer[FRAME_SIZE]) {
    uint16_t received_checksum_net;
    memcpy(&received_checksum_net, buffer + OFF_CHECK, sizeof(uint16_t));
    uint16_t received_checksum = ntohs(received_checksum_net);

    uint16_t calculated_checksum = calculate_checksum_internal(buffer);

    return (received_checksum == calculated_checksum);
}

int deserialize_frame(unsigned char buffer[FRAME_SIZE], Frame* f) {
    if (!validate_checksum(buffer)) {
        // Checksum incorrecto
        return 0; 
    }

    f->type = buffer[OFF_TYPE];

    memset(f->origin, 0, ORIGIN_SIZE);
    memcpy(f->origin, buffer + OFF_ORIGIN, ORIGIN_SIZE);

    memset(f->destination, 0, DEST_SIZE);
    memcpy(f->destination, buffer + OFF_DEST, DEST_SIZE);

    uint16_t len_net;
    memcpy(&len_net, buffer + OFF_LEN, sizeof(uint16_t));
    f->data_length = ntohs(len_net);

    memset(f->data, 0, DATA_SIZE);
    memcpy(f->data, buffer + OFF_DATA, DATA_SIZE);

    uint16_t check_net;
    memcpy(&check_net, buffer + OFF_CHECK, sizeof(uint16_t));
    f->checksum = ntohs(check_net);

    return 1;
}