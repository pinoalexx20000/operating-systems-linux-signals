#ifndef PERSISTENCE_H_H
#define PERSISTENCE_H

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "structs.h"
#include "auxiliars.h"
#include "safe_print.h"

/***********************************************
*
* @Finalitat: Llegeix les dades del regne des d’un fitxer i inicialitza l’estructura Kingdom.
* @Parametres:
*   - k: punter a l’estructura Kingdom on es desaran les dades.
*   - fd: file descriptor obert amb la informació del regne.
* @Retorn: void.
*
************************************************/

void getKingdom(Kingdom *k, int fd);

/***********************************************
*
* @Finalitat: Carrega la llista de productes des d’un fitxer binari.
* @Parametres:
*   - products: punter doble a la llista dinàmica de productes.
*   - fd: descriptor del fitxer obert amb productes.
* @Retorn: nombre total de productes carregats.
*
************************************************/

int getProducts(Product **products, int fd);

/***********************************************
*
* @Finalitat: Desa la llista de trade a un fitxer dins del directori del regne.
* @Parametres:
*   - ctx: context global amb tota la informació del programa.
*   - path: ruta del directori del regne.
*   - trade_list: llista de productes a desar.
*   - trade_count: nombre de productes a la llista.
* @Retorn: void.
*
************************************************/

void saveList(GlobalContext *ctx, char *path, TradeList *trade_list, int trade_count);

/**
 * @brief Guarda la lista de productos en un fichero de texto temporal para enviarlo.
 * Formato: "Nombre Cantidad" por línea.
 */
int saveProductsToTempFile(Product *products, int n_products, const char *filename);

void create_folder_safe(const char *path);
int saveTradeListToTempFile(TradeList *list, int count, const char *filename);

void update_persistence_stock(GlobalContext *ctx, const char *filename);

#endif