#ifndef _SAFEPRINT_H_
#define _SAFEPRINT_H_

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "structs.h"

/**
 * @brief Inicializa el sistema de impresión segura
 * @param ctx Contexto global
 * @return 0 si éxito, -1 si error
 */
int initPrint(GlobalContext *ctx);

/**
 * @brief Destruye el semáforo de impresión
 * @param ctx Contexto global
 * @return 0 si éxito, -1 si error
 */
int destroyPrint(GlobalContext *ctx);

/**
 * @brief Imprime un mensaje de forma sincronizada (thread-safe)
 * @param ctx Contexto global
 * @param msg Mensaje a imprimir
 */
void safePrint(GlobalContext *ctx, const char *msg);

#endif